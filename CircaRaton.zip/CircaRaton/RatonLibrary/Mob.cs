﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RatonLibrary
{
    public class Mob : Character
    {
        public Mob(string mobType, int hp, int ap) : base(hp, ap)
        {
            MobType = mobType;
        }
        public string MobType { get; set; }
    }
}
