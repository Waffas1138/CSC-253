﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RatonLibrary
{
    public class MobList
    {
        public  MobList()
        {
            Mob FireFox = new Mob("Fire Fox", 25, 5);
            Mob TheOwlVengers = new Mob("The Owl-Vengers", 120, 50);
            Mob WeaselWicked = new Mob("Weasel Wicked", 30, 15);
            Mob HellbentHawk = new Mob("Hellbent Hawk", 50, 10);
            Mob KingKobra = new Mob("King Kobra", 15, 35);
            Mob Kilik = new Mob("Kilik", 60, 25);
            Mob Leviathan = new Mob("Leviathan", 175, 75);
            Mob Seraph = new Mob("Seraph", 100, 30);
            Mob BloodHound = new Mob("BloodHound", 100, 60);
            Mob Kerberus = new Mob("Kerberus", 125, 100);
            Mob Goliath = new Mob("Goliath", 250, 50);
            Mob EtherDrake = new Mob("Ether Drake", 140, 100);
            Mob TiyanaVek = new Mob("Tiyana Vek", 75, 65);
            Mob Pekka = new Mob("Pekka", 90, 20);
            Mob FrossMoth = new Mob("FrossMoth", 65, 10);
            List<Character> characters = new List<Character>();
            characters.Add(FireFox);
            characters.Add(TheOwlVengers);
            characters.Add(WeaselWicked);
            characters.Add(HellbentHawk);
            characters.Add(KingKobra);
            characters.Add(Kilik);
            characters.Add(Leviathan);
            characters.Add(Seraph);
            characters.Add(BloodHound);
            characters.Add(Kerberus);
            characters.Add(Goliath);
            characters.Add(EtherDrake);
            characters.Add(TiyanaVek);
            characters.Add(Pekka);
            characters.Add(FrossMoth);
            Console.WriteLine("Fire Fox" + FireFox);
        }
    }
}
