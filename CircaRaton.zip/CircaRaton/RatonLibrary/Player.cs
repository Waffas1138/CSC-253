﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RatonLibrary
{
    public class Player : Character
    {
        public Player(int hp, int ap, int armorValue) : base(hp, ap)
        {
            ArmorValue = armorValue;
        }
        public int ArmorValue { get; set; }

     
    }
}
