﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoLib
{
    public class Car : Auto
    {
        public Car(int doors, string make, string model, decimal price, double trunkSpace): base(doors, make, model, price)
        {
            TrunkSpace = trunkSpace;
        }

        public double TrunkSpace { get; set; }
    }
}
