﻿/**
* 8/20/21
* CSC 253
* Travis Bivins
* This program will display a table that converts Celsius to Fahrenheit from 0-20
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CelsiusToFahrenheit
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            double celsius; // to hold the celsius temperature
            double fahrenheit; // to hold the fahrenheit temperature

            //displays a header for the table
            temperatureListBox.Items.Add("Celsius\tFahrenheit");

            //displays the table of temperatures
            for (celsius = 0; celsius <= 20; celsius++)
            {
                fahrenheit = (9.0 / 5.0) * celsius + 32;
                temperatureListBox.Items.Add(celsius + "\t" + fahrenheit);
            }
        }
    }
}
