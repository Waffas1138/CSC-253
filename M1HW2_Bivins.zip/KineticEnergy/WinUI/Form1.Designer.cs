﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ObjectMass = new System.Windows.Forms.Label();
            this.ObjectVelocity = new System.Windows.Forms.Label();
            this.Kinetic = new System.Windows.Forms.Label();
            this.massTextBox = new System.Windows.Forms.TextBox();
            this.velocityTextBox = new System.Windows.Forms.TextBox();
            this.KineticEnergyTotal = new System.Windows.Forms.Label();
            this.CalcKineticEnergy = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ObjectMass
            // 
            this.ObjectMass.AutoSize = true;
            this.ObjectMass.Location = new System.Drawing.Point(75, 35);
            this.ObjectMass.Name = "ObjectMass";
            this.ObjectMass.Size = new System.Drawing.Size(119, 13);
            this.ObjectMass.TabIndex = 0;
            this.ObjectMass.Text = "Enter the object\'s mass:";
            // 
            // ObjectVelocity
            // 
            this.ObjectVelocity.AutoSize = true;
            this.ObjectVelocity.Location = new System.Drawing.Point(75, 85);
            this.ObjectVelocity.Name = "ObjectVelocity";
            this.ObjectVelocity.Size = new System.Drawing.Size(131, 13);
            this.ObjectVelocity.TabIndex = 1;
            this.ObjectVelocity.Text = "Enter the object\'s velocity;";
            // 
            // Kinetic
            // 
            this.Kinetic.AutoSize = true;
            this.Kinetic.Location = new System.Drawing.Point(75, 127);
            this.Kinetic.Name = "Kinetic";
            this.Kinetic.Size = new System.Drawing.Size(74, 13);
            this.Kinetic.TabIndex = 2;
            this.Kinetic.Text = "Kinetic energy";
            // 
            // massTextBox
            // 
            this.massTextBox.Location = new System.Drawing.Point(250, 35);
            this.massTextBox.Name = "massTextBox";
            this.massTextBox.Size = new System.Drawing.Size(100, 20);
            this.massTextBox.TabIndex = 3;
            // 
            // velocityTextBox
            // 
            this.velocityTextBox.Location = new System.Drawing.Point(250, 82);
            this.velocityTextBox.Name = "velocityTextBox";
            this.velocityTextBox.Size = new System.Drawing.Size(100, 20);
            this.velocityTextBox.TabIndex = 4;
            // 
            // KineticEnergyTotal
            // 
            this.KineticEnergyTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.KineticEnergyTotal.Cursor = System.Windows.Forms.Cursors.Default;
            this.KineticEnergyTotal.Location = new System.Drawing.Point(250, 127);
            this.KineticEnergyTotal.Name = "KineticEnergyTotal";
            this.KineticEnergyTotal.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.KineticEnergyTotal.Size = new System.Drawing.Size(100, 25);
            this.KineticEnergyTotal.TabIndex = 5;
            this.KineticEnergyTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CalcKineticEnergy
            // 
            this.CalcKineticEnergy.Location = new System.Drawing.Point(60, 219);
            this.CalcKineticEnergy.Name = "CalcKineticEnergy";
            this.CalcKineticEnergy.Size = new System.Drawing.Size(146, 66);
            this.CalcKineticEnergy.TabIndex = 6;
            this.CalcKineticEnergy.Text = "Calculate Kinetic Energy";
            this.CalcKineticEnergy.UseVisualStyleBackColor = true;
            this.CalcKineticEnergy.Click += new System.EventHandler(this.CalcKineticEnergy_Click);
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(250, 219);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(146, 66);
            this.Exit.TabIndex = 7;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.CalcKineticEnergy);
            this.Controls.Add(this.KineticEnergyTotal);
            this.Controls.Add(this.velocityTextBox);
            this.Controls.Add(this.massTextBox);
            this.Controls.Add(this.Kinetic);
            this.Controls.Add(this.ObjectVelocity);
            this.Controls.Add(this.ObjectMass);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ObjectMass;
        private System.Windows.Forms.Label ObjectVelocity;
        private System.Windows.Forms.Label Kinetic;
        private System.Windows.Forms.TextBox massTextBox;
        private System.Windows.Forms.TextBox velocityTextBox;
        private System.Windows.Forms.Label KineticEnergyTotal;
        private System.Windows.Forms.Button CalcKineticEnergy;
        private System.Windows.Forms.Button Exit;
    }
}

