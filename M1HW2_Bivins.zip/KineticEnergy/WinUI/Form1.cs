﻿/**
* 8/20/2021
* CSC 253
* Travis Bivins
* This program will allow the user to enter the mass and velocity 
* of any object to find out the kinetic energy it is
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // The KineticEnergy method accepts mass and velocity
        // as arguements and returns kinetic energy
        private double KineticEnergy(double mass, double velocity)
        {
            return 0.5 * mass * Math.Pow(velocity, 2.0);
        }

        private void CalcKineticEnergy_Click(object sender, EventArgs e)
        {
            double mass, velocity, energy;

            //get the mass
            if (double.TryParse(massTextBox.Text, out mass))
            {
                // get the velocity
                if(double.TryParse(velocityTextBox.Text, out velocity))
                {
                    // get the kinetc energy
                    energy = KineticEnergy(mass, velocity);

                    //displays the kinetic energy
                    KineticEnergyTotal.Text = energy.ToString("n1");
                }
                else
                {
                    // If the user inputs anything that is not a number
                    MessageBox.Show("Velocity is invalid.");
                }
            }
            else
            {
                // If the user inputs anything that is not a number
                MessageBox.Show("Mass is invalid.");
            }
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            // Closes the program when clicked
            this.Close();
        }
    }
}
