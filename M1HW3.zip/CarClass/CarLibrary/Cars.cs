﻿/**
 * 8/23/2021
 * CSC 253
 * Travis Bivins
 * This program will allow the user to input their pets name, age and type while using a class 
 * object in order to do so in the library.
 */
using System;

namespace CarLibrary
{
    public class Cars
    {
        public Cars(string make, int year, int speed)
        {
            Make = make;
            Year = year;
            Speed = speed;
        }

        public string Make { get; set; }
        public int Year { get; set; }
        public int Speed { get; set; }
    }
}
