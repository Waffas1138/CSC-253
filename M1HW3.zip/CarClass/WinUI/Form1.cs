﻿/**
 * 8/23/2021
 * CSC 253
 * Travis Bivins
 * This program will allow the user to input their cars year, make and speed of the vehicle as well as allowing the user to
 * increase or decrease the speed by 5 everytime it is called by an accelerate or brake method 
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CarLibrary; 

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // Calls the class and methods creating in the seperate library
        Cars cars;
        private void enterInfoButton_Click(object sender, EventArgs e)
        {
            int year = 0;
            string make = makeTextBox.Text;
            int speed = 0;

            if (int.TryParse(yearTextBox.Text, out year) && !string.IsNullOrWhiteSpace(make) && int.TryParse(speedTextBox.Text, out speed))
            {
                cars = new Cars(make, year, speed);
            }
            else
                MessageBox.Show("Please enter a valid input into the boxes");// error message for when an invlaid input is used
        }

        private void displayInfoButton_Click(object sender, EventArgs e)
        {
            try
            {
                CarOutPut.Items.Add("Hello there, we have a " + cars.Year + " " + cars.Make); 
                CarOutPut.Items.Add("and that vehicle is currently clocked in at " + cars.Speed + " miles per hour");
            }
            catch (NullReferenceException)
            {
                MessageBox.Show("Please enter information first and try again");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            
        }
    }
}
