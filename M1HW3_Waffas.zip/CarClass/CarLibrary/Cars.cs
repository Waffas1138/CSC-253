﻿/**
 * 8/23/2021
 * CSC 253
 * Travis Bivins
 * This program will allow the user to input their pets name, age and type while using a class 
 * object in order to do so in the library.
 */
using System;

namespace CarLibrary
{
    public class Cars
    {
        public Cars(string make, int year, int speed)
        {
            Make = make;
            Year = year;
            Speed = speed;
        }
        // This holds the objects needed for the cars make, year and the speed without needing a whole mess for it
        // and also allowing it it be changed whenever and not being predefined so the user can have any input they'd like
        public string Make { get; set; }
        public int Year { get; set; }
        public int Speed { get; set; }

        public void AccSpeed(int speedIncrement)
        {
            //This sets up to being able to increase the speed when the button will be clicked
            Speed += speedIncrement;
        }
        public void DecSpeed(int speedDecrement)
        {
            //This sets up to being able to decrease the speed when the button will be clicked
            Speed -= speedDecrement;
        }
    }
}

