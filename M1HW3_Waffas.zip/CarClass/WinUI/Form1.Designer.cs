﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.yearLabel = new System.Windows.Forms.Label();
            this.makeLabel = new System.Windows.Forms.Label();
            this.speedLabel = new System.Windows.Forms.Label();
            this.yearTextBox = new System.Windows.Forms.TextBox();
            this.makeTextBox = new System.Windows.Forms.TextBox();
            this.speedTextBox = new System.Windows.Forms.TextBox();
            this.enterInfoButton = new System.Windows.Forms.Button();
            this.displayInfoButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.CarOutPut = new System.Windows.Forms.ListBox();
            this.accelerateButton = new System.Windows.Forms.Button();
            this.decelerateButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // yearLabel
            // 
            this.yearLabel.AutoSize = true;
            this.yearLabel.Location = new System.Drawing.Point(119, 43);
            this.yearLabel.Name = "yearLabel";
            this.yearLabel.Size = new System.Drawing.Size(66, 15);
            this.yearLabel.TabIndex = 0;
            this.yearLabel.Text = "Model Year";
            // 
            // makeLabel
            // 
            this.makeLabel.AutoSize = true;
            this.makeLabel.Location = new System.Drawing.Point(119, 116);
            this.makeLabel.Name = "makeLabel";
            this.makeLabel.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.makeLabel.Size = new System.Drawing.Size(57, 15);
            this.makeLabel.TabIndex = 1;
            this.makeLabel.Text = "Car Make";
            // 
            // speedLabel
            // 
            this.speedLabel.AutoSize = true;
            this.speedLabel.Location = new System.Drawing.Point(119, 176);
            this.speedLabel.Name = "speedLabel";
            this.speedLabel.Size = new System.Drawing.Size(82, 15);
            this.speedLabel.TabIndex = 2;
            this.speedLabel.Text = "Current Speed";
            // 
            // yearTextBox
            // 
            this.yearTextBox.Location = new System.Drawing.Point(285, 43);
            this.yearTextBox.Name = "yearTextBox";
            this.yearTextBox.Size = new System.Drawing.Size(100, 23);
            this.yearTextBox.TabIndex = 4;
            // 
            // makeTextBox
            // 
            this.makeTextBox.Location = new System.Drawing.Point(285, 116);
            this.makeTextBox.Name = "makeTextBox";
            this.makeTextBox.Size = new System.Drawing.Size(100, 23);
            this.makeTextBox.TabIndex = 5;
            // 
            // speedTextBox
            // 
            this.speedTextBox.Location = new System.Drawing.Point(285, 176);
            this.speedTextBox.Name = "speedTextBox";
            this.speedTextBox.Size = new System.Drawing.Size(100, 23);
            this.speedTextBox.TabIndex = 6;
            // 
            // enterInfoButton
            // 
            this.enterInfoButton.Location = new System.Drawing.Point(86, 229);
            this.enterInfoButton.Name = "enterInfoButton";
            this.enterInfoButton.Size = new System.Drawing.Size(92, 54);
            this.enterInfoButton.TabIndex = 7;
            this.enterInfoButton.Text = "Enter Car Information";
            this.enterInfoButton.UseVisualStyleBackColor = true;
            this.enterInfoButton.Click += new System.EventHandler(this.enterInfoButton_Click);
            // 
            // displayInfoButton
            // 
            this.displayInfoButton.Location = new System.Drawing.Point(216, 229);
            this.displayInfoButton.Name = "displayInfoButton";
            this.displayInfoButton.Size = new System.Drawing.Size(92, 54);
            this.displayInfoButton.TabIndex = 8;
            this.displayInfoButton.Text = "Display Car Information";
            this.displayInfoButton.UseVisualStyleBackColor = true;
            this.displayInfoButton.Click += new System.EventHandler(this.displayInfoButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(351, 239);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(92, 35);
            this.exitButton.TabIndex = 9;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // CarOutPut
            // 
            this.CarOutPut.FormattingEnabled = true;
            this.CarOutPut.ItemHeight = 15;
            this.CarOutPut.Location = new System.Drawing.Point(93, 302);
            this.CarOutPut.Name = "CarOutPut";
            this.CarOutPut.Size = new System.Drawing.Size(349, 124);
            this.CarOutPut.TabIndex = 10;
            // 
            // accelerateButton
            // 
            this.accelerateButton.Location = new System.Drawing.Point(469, 302);
            this.accelerateButton.Name = "accelerateButton";
            this.accelerateButton.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.accelerateButton.Size = new System.Drawing.Size(101, 46);
            this.accelerateButton.TabIndex = 11;
            this.accelerateButton.Text = "Accelerate by 5";
            this.accelerateButton.UseVisualStyleBackColor = true;
            this.accelerateButton.Click += new System.EventHandler(this.accelerateButton_Click);
            // 
            // decelerateButton
            // 
            this.decelerateButton.Location = new System.Drawing.Point(469, 380);
            this.decelerateButton.Name = "decelerateButton";
            this.decelerateButton.Size = new System.Drawing.Size(101, 46);
            this.decelerateButton.TabIndex = 12;
            this.decelerateButton.Text = "Decelerate by 5";
            this.decelerateButton.UseVisualStyleBackColor = true;
            this.decelerateButton.Click += new System.EventHandler(this.decelerateButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(585, 450);
            this.Controls.Add(this.decelerateButton);
            this.Controls.Add(this.accelerateButton);
            this.Controls.Add(this.CarOutPut);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.displayInfoButton);
            this.Controls.Add(this.enterInfoButton);
            this.Controls.Add(this.speedTextBox);
            this.Controls.Add(this.makeTextBox);
            this.Controls.Add(this.yearTextBox);
            this.Controls.Add(this.speedLabel);
            this.Controls.Add(this.makeLabel);
            this.Controls.Add(this.yearLabel);
            this.Name = "Form1";
            this.Text = "Car Information";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label yearLabel;
        private System.Windows.Forms.Label makeLabel;
        private System.Windows.Forms.Label speedLabel;
        private System.Windows.Forms.TextBox yearTextBox;
        private System.Windows.Forms.TextBox modelTextBox;
        private System.Windows.Forms.TextBox speedTextBox;
        private System.Windows.Forms.Button enterInfoButton;
        private System.Windows.Forms.Button displayInfoButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ListBox CarOutPut;
        private System.Windows.Forms.TextBox makeTextBox;
        private System.Windows.Forms.Button accelerateButton;
        private System.Windows.Forms.Button decelerateButton;
    }
}

