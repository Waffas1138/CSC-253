﻿/**
* 8/28/2021
* CSC 253
* Travis Bivins
* Program with three overloaded methods for area of a circle, rectangle and cylinder
*/
using System;

namespace AreaLibrary
{
    public class Area
    {

            public double area(double r)
            {
                double area = Math.PI * Math.Pow(r, 2);
                return area;
            }
            public double area(double r, double h)
            {
                double area = Math.PI * Math.Pow(r, 2) * h;
                return area;
            }
            public double area(double w, int l)
            {
            double area = w * l;
            return area;
            }

    }
}




