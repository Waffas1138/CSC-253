﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.radiusCylText = new System.Windows.Forms.TextBox();
            this.heightCylText = new System.Windows.Forms.TextBox();
            this.widthRectText = new System.Windows.Forms.TextBox();
            this.lengthRectText = new System.Windows.Forms.TextBox();
            this.radiusCircText = new System.Windows.Forms.TextBox();
            this.RectOutPut = new System.Windows.Forms.ListBox();
            this.CylinderOutPut = new System.Windows.Forms.ListBox();
            this.CircleOutPut = new System.Windows.Forms.ListBox();
            this.CircleAreaButton = new System.Windows.Forms.Button();
            this.CylinderAreaButton = new System.Windows.Forms.Button();
            this.RectangleAreaButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Radius";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(248, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Length";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(248, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Width";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(504, 43);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Radius";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(506, 86);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Height";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(28, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Area of a Circle";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(248, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(102, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Area of a Rectangle";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(504, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Area of a cylinder";
            // 
            // radiusCylText
            // 
            this.radiusCylText.Location = new System.Drawing.Point(582, 43);
            this.radiusCylText.Name = "radiusCylText";
            this.radiusCylText.Size = new System.Drawing.Size(128, 20);
            this.radiusCylText.TabIndex = 8;
            // 
            // heightCylText
            // 
            this.heightCylText.Location = new System.Drawing.Point(582, 83);
            this.heightCylText.Name = "heightCylText";
            this.heightCylText.Size = new System.Drawing.Size(128, 20);
            this.heightCylText.TabIndex = 9;
            // 
            // widthRectText
            // 
            this.widthRectText.Location = new System.Drawing.Point(304, 36);
            this.widthRectText.Name = "widthRectText";
            this.widthRectText.Size = new System.Drawing.Size(128, 20);
            this.widthRectText.TabIndex = 10;
            // 
            // lengthRectText
            // 
            this.lengthRectText.Location = new System.Drawing.Point(304, 83);
            this.lengthRectText.Name = "lengthRectText";
            this.lengthRectText.Size = new System.Drawing.Size(128, 20);
            this.lengthRectText.TabIndex = 11;
            // 
            // radiusCircText
            // 
            this.radiusCircText.Location = new System.Drawing.Point(74, 36);
            this.radiusCircText.Name = "radiusCircText";
            this.radiusCircText.Size = new System.Drawing.Size(128, 20);
            this.radiusCircText.TabIndex = 12;
            // 
            // RectOutPut
            // 
            this.RectOutPut.FormattingEnabled = true;
            this.RectOutPut.Location = new System.Drawing.Point(269, 181);
            this.RectOutPut.Name = "RectOutPut";
            this.RectOutPut.Size = new System.Drawing.Size(181, 147);
            this.RectOutPut.TabIndex = 18;
            // 
            // CylinderOutPut
            // 
            this.CylinderOutPut.FormattingEnabled = true;
            this.CylinderOutPut.Location = new System.Drawing.Point(520, 192);
            this.CylinderOutPut.Name = "CylinderOutPut";
            this.CylinderOutPut.Size = new System.Drawing.Size(210, 147);
            this.CylinderOutPut.TabIndex = 19;
            // 
            // CircleOutPut
            // 
            this.CircleOutPut.FormattingEnabled = true;
            this.CircleOutPut.Location = new System.Drawing.Point(31, 164);
            this.CircleOutPut.Name = "CircleOutPut";
            this.CircleOutPut.Size = new System.Drawing.Size(183, 147);
            this.CircleOutPut.TabIndex = 20;
            // 
            // CircleAreaButton
            // 
            this.CircleAreaButton.Location = new System.Drawing.Point(31, 86);
            this.CircleAreaButton.Name = "CircleAreaButton";
            this.CircleAreaButton.Size = new System.Drawing.Size(102, 36);
            this.CircleAreaButton.TabIndex = 23;
            this.CircleAreaButton.Text = "Display Area of a Circle";
            this.CircleAreaButton.UseVisualStyleBackColor = true;
            this.CircleAreaButton.Click += new System.EventHandler(this.CircleAreaButton_Click);
            // 
            // CylinderAreaButton
            // 
            this.CylinderAreaButton.Location = new System.Drawing.Point(520, 127);
            this.CylinderAreaButton.Name = "CylinderAreaButton";
            this.CylinderAreaButton.Size = new System.Drawing.Size(102, 36);
            this.CylinderAreaButton.TabIndex = 22;
            this.CylinderAreaButton.Text = "Display Area of a Cylinder";
            this.CylinderAreaButton.UseVisualStyleBackColor = true;
            this.CylinderAreaButton.Click += new System.EventHandler(this.CylinderAreaButton_Click);
            // 
            // RectangleAreaButton
            // 
            this.RectangleAreaButton.Location = new System.Drawing.Point(251, 127);
            this.RectangleAreaButton.Name = "RectangleAreaButton";
            this.RectangleAreaButton.Size = new System.Drawing.Size(102, 36);
            this.RectangleAreaButton.TabIndex = 21;
            this.RectangleAreaButton.Text = "Display Area of a Rectangle";
            this.RectangleAreaButton.UseVisualStyleBackColor = true;
            this.RectangleAreaButton.Click += new System.EventHandler(this.RectangleAreaButton_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(287, 362);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(145, 51);
            this.ExitButton.TabIndex = 24;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.CircleAreaButton);
            this.Controls.Add(this.CylinderAreaButton);
            this.Controls.Add(this.RectangleAreaButton);
            this.Controls.Add(this.CircleOutPut);
            this.Controls.Add(this.CylinderOutPut);
            this.Controls.Add(this.RectOutPut);
            this.Controls.Add(this.radiusCircText);
            this.Controls.Add(this.lengthRectText);
            this.Controls.Add(this.widthRectText);
            this.Controls.Add(this.heightCylText);
            this.Controls.Add(this.radiusCylText);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Area Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox radiusCylText;
        private System.Windows.Forms.TextBox heightCylText;
        private System.Windows.Forms.TextBox widthRectText;
        private System.Windows.Forms.TextBox lengthRectText;
        private System.Windows.Forms.TextBox radiusCircText;
        private System.Windows.Forms.ListBox RectOutPut;
        private System.Windows.Forms.ListBox CylinderOutPut;
        private System.Windows.Forms.ListBox CircleOutPut;
        private System.Windows.Forms.Button CircleAreaButton;
        private System.Windows.Forms.Button CylinderAreaButton;
        private System.Windows.Forms.Button RectangleAreaButton;
        private System.Windows.Forms.Button ExitButton;
    }
}

