﻿/**
* 8/28/2021
* CSC 253
* Travis Bivins
* Program with three overloaded methods for area of a circle, rectangle and cylinder
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        public class Area
        {
            // This is the area with the overloaded methods for each of the area of the shapes
            public double area(double r)
            {
                // This one is for figuring out the area of a circle
                double area = Math.PI * Math.Pow(r, 2);
                return area;
            }
            public double area(double r, double h)
            {
                // this one is used for cylinders
                double area = Math.PI * Math.Pow(r, 2) * h;
                return area;
            }
            public double area(double w, int l)
            {
                // Lastly this one is being used for the are of a rectangle
                double area = w * l;
                return area;
            }
        }

        private void CylinderAreaButton_Click(object sender, EventArgs e)
        {
            double r = 0;
            double h = 0;
            if (Double.TryParse(radiusCylText.Text, out r) && Double.TryParse(heightCylText.Text, out h))
            {
                // This section is setting the fields to 0 and the TryPrase is there to make sure the number inputed to the fields
                // shows up properly for the user

                // And this little thing sets up a new area function that is then pulling from the overloads into the corresponding method
                // in this case it will be a cylinder as it has the radius and height
                Area a = new Area();
                double radius = r;
                double height = h;
                double cyl = a.area(radius, height);
                CylinderOutPut.Items.Add("The area of your cylinder is " + cyl);
            }
            else
                MessageBox.Show("Please enter a valid input into the boxes");
        }

        private void RectangleAreaButton_Click(object sender, EventArgs e)
        {
            double w = 0;
            int l = 0;
            if (Double.TryParse(widthRectText.Text, out w) && int.TryParse(lengthRectText.Text, out l))
            {
                // This section is setting the fields to 0 and the TryPrase is there to make sure the number inputed to the fields
                // shows up properly for the user

                // And this little thing sets up a new area function that is then pulling from the overloads into the corresponding method
                // in this case it will be for a rectangle as it has the width and height calculations
                Area a = new Area();
                double width = w;
                int length = l;
                double rect = a.area(width, length);
                RectOutPut.Items.Add("The area if your rectangle is " + rect);
            }
            else
                MessageBox.Show("Please enter a valid input into the boxes");
        }

        private void CircleAreaButton_Click(object sender, EventArgs e)
        {
            double r = 0;
            if (Double.TryParse(radiusCircText.Text, out r))
            {
                // This section is setting the fields to 0 and the TryPrase is there to make sure the number inputed to the fields
                // shows up properly for the user

                // And this little thing sets up a new area function that is then pulling from the overloads into the corresponding method
                // in this case it will be a circle as it has only has the radius calculation inside of it
                Area a = new Area();
                double radius = r;
                double cir = a.area(radius);
                CircleOutPut.Items.Add("The area of your circle is " + cir);
            }
            else
                MessageBox.Show("Please enter a valid input into the boxes");

        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            // Just closes when hit
            this.Close();
        }
    }
}
