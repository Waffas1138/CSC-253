﻿/**
 * 9/1/2021
 * CSC 253  
 * Travis Bivins
 *  This program lets the user enter words into a textboox and then will show them a popup messagebox showing them how many words was in it
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordCountLibrary
{
    public class WordCount
    {
        public WordCount(string count)
        {
            // This little area sets up count variable and will allow to hold anything without being predefined so it will be up to the user what is included
            Count = count;
        }
        public string Count { get; set; }

    }
}
