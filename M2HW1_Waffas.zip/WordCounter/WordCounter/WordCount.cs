﻿using System;

namespace WordCounterLibrary
{
    public class WordCount
    {
        public WordCount(string count, string type, int age)
        {
            Count = count;

        }
        public string Count { get; set; }

    }
}

