﻿/**
 * 9/1/2021
 * CSC 253  
 * Travis Bivins
 *  This program lets the user enter words into a textboox and then will show them a popup messagebox showing them how many words was in it and now calculates the average
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WordCountLibrary;
namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        WordCount wordcount;

        private void enterButton_Click(object sender, EventArgs e)
        {
            //Using .Trim so it will not count extra spaces if any were to be input as well as setting the textbox to the count variable
            string count = wordCountText.Text.Trim();

            if (!string.IsNullOrWhiteSpace(count))
            {
                //sets the method from the library to the variable set in here so the count will work properly
                wordcount = new WordCount(count);
                //This messagebox will show the user how many words they had entered by calling the countwords method below that handles the calculations
                WordOutOut.Items.Add("There was a total of " + CountWords(count) + " words in what you entered");
                //This sets up a string named var to use the count string in order to calculate how many words are inside of it
                string var = count;
                int totals = 0;
                for (int i = 0; i < var.Length; i++)
                {
                    totals++;
                }
                // This uses the amount of words from the for loop and divides it by the the total count from the countwords method
                int average = totals / CountWords(count);
                WordOutOut.Items.Add("Within that sentence you have an average of  " + average + " words inputted");
                
            }
            else
                // error catch message if an invalid data type is entered
                
                 MessageBox.Show("Please enter a valid input into the text box.");
            
        }
        private int CountWords(string count)
        {
            //Split is to be used so it will split the words by spaces inorder to be counted
            string[] totalWords = count.Split(' ');
            // also returns the number of the length of the words that have been entered and skips the spaces so they do not get counted
            return totalWords.Length;
        }
       
        private void exitButton_Click(object sender, EventArgs e)
        {
            //closes the program
            this.Close();
            
        }
    }
}
