﻿/**
* 9/11/2021
* CSC 253
* Travis Bivins
* This program is an added on version of the word printer and now it will show the user the most common character that they have entered
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WordInputLibrary;
namespace WinUi
{
    public partial class frequentLetter : Form
    {
        public frequentLetter()
        {
            InitializeComponent();
        }
        WordInput wordInput;
     
        private void enterButton_Click(object sender, EventArgs e)
        {
            //Using .Trim so it will not count extra spaces if any were to be input as well as setting the textbox to the count variable
            string count = wordCountText.Text.Trim();

            if (!string.IsNullOrWhiteSpace(count))
            {
                //sets the method from the library to the variable set in here so the count will work properly
                wordInput = new WordInput(count);
                //This messagebox will show the user how many words they had entered by calling the countwords method below that handles the calculations
                WordOutOut.Items.Add("There was a total of " + wordInput.CountWords(count) + " words in what you entered");
                //This is now setting up a char system so when the string is input into the program it will then go through
                // all of this and assign it an ascii/char signature and do checks to see which one is the most common and then display it in the end for them
                String str = count;
                int[] charCount = new int[256];
                int length = str.Length;
                for (int i = 0; i < length; i++)
                {
                    charCount[str[i]]++;
                }
                int maxCount = -1;
                char character = ' ';
                for (int i = 0; i < length; i++)
                {
                    if (maxCount < charCount[str[i]])
                    {
                        maxCount = charCount[str[i]];
                        character = str[i];
                    }
                }
                //After all the checks are done with the for statements to check what was the most common it will now display for the user
                // what it was they typed the most
                WordOutOut.Items.Add("The most repeated character that you had typed was " + character);
            }
            else
                // error catch message if an invalid data type is entered

                MessageBox.Show("Please enter a valid input into the text box.");
        }
        
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

    }
}
