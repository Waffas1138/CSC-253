﻿/**
* 9/11/2021
* CSC 253
* Travis Bivins
* This program is an added on version of the word printer and now it will show the user the most common character that they have entered
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordInputLibrary
{
    public class WordInput
    {
        public WordInput(string count)
        {
            // This little area sets up count variable and will allow to hold anything without being predefined so it will be up to the user what is included
            Count = count;
            string var = count;
            int totals = 0;
            for (int i = 0; i < var.Length; i++)
            {
                totals++;
            }           
        }
        public string Count { get; set; }
        public int CountWords(string count)
        {
            //Split is to be used so it will split the words by spaces inorder to be counted
            string[] totalWords = count.Split(' ');
            // also returns the number of the length of the words that have been entered and skips the spaces so they do not get counted
            return totalWords.Length;
        }
        
    }
   
}
 