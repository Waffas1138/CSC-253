﻿/**
* 9/11/2021
* CSC 253
* Travis Bivins
* This program will seperate the string inputted as long as there is a uppercase letter the user is using each time
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WordSeparatorLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        WordSeparator wordSeparator; 
        private void enterButton_Click(object sender, EventArgs e)
        {
            string count = wordCountText.Text.Trim();

            if (!string.IsNullOrWhiteSpace(count))
            {
                //sets the method from the library to the variable set in here so the count will work properly
                wordSeparator = new WordSeparator(count);
                //This messagebox will show the user how many words they had entered by calling the countwords method below that handles the calculations
              
                //This messagebox will give us separated version of the string inserted from the user.
                WordOutOut.Items.Add("You're sentance spaced out is " + wordSeparator.wordSeparator(count));
            }
            else
                // error catch message if an invalid data type is entered

                MessageBox.Show("Please enter a valid input into the text box.");
        }
    
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
