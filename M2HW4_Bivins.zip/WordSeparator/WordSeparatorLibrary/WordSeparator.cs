﻿/**
* 9/11/2021
* CSC 253
* Travis Bivins
* This program will seperate the string inputted as long as there is a uppercase letter the user is using each time
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordSeparatorLibrary
{
    public class WordSeparator
    {
        public WordSeparator(string count)
        {
            // This little area sets up count variable and will allow to hold anything without being predefined so it will be up to the user what is included
            Count = count;
            string var = count;
            int totals = 0;
            for (int i = 0; i < var.Length; i++)
            {
                totals++;
            }
        }
        public string Count { get; set; }
        
        public string wordSeparator(string count)
        {
            //This is setting up word separator so when the words are typed in a capital letter it will separate them into the sentence
            var test = count;
            var final = "";
            bool firstCharacterCheckIsDone = false;
            foreach (char c in test)
            {
                //If the character is uppercase then it will insert a space between the words, can't get it to work with lowercase as well
                if (char.IsUpper(c))
                {
                    if (test.IndexOf(c) == 0 && !firstCharacterCheckIsDone)
                    {
                        final += " " + c.ToString();

                        //This here will make sure only first character is in Upper case
                        //doesn't matter if the same character is being repeated elsewhere
                        firstCharacterCheckIsDone = true;
                    }
                    else
                        final += " " + c.ToString().ToLower();
                }
                else
                    final += c.ToString();
            }
            //Trims the string so it will give us the result when it is all said and done
            return final.Trim();
        }
    }
}
