﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace RandNumLibrary
{
    public class RandNum
    {
        public RandNum(int userNum)
        {
            UserNum = userNum;
            
        }
        public int UserNum { get; set; }
        public static string MakeDocument(int userNum)
        {
            //Sets the int to 0 for the random numbers to generate properly
            int randomNumber = 0;
            try
            {
                // calls the file Writer to get it all prepped
                StreamWriter outputFile;
                
                outputFile = File.CreateText("Random_Numbers.txt");//File is created with the name Random_Numbers
                Random Rand = new Random();
                //This little area sets up the random number generator and loops around a total of x amount of times that the user entered
                for (int count = 0; count < userNum; count++)
                {
                    randomNumber = Rand.Next(1, 101);
                    outputFile.WriteLine(randomNumber);

                }
                outputFile.Close();
                return "Save Complete";//Save message for the users
            }
            catch(Exception ex)
            {
                string test = (ex.Message);//error message for the users
                return test;
            }
        }
    }
}
