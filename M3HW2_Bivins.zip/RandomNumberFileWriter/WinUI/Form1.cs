﻿/**
* 9/18/2021
* CSC 253
* Travis Bivins
* The user will enter a number and then it will randomly generate those numbers inside of a txt file for the user
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using RandNumLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        RandNum randNum;
        private void enterNumButton_Click(object sender, EventArgs e)
        {
            int userNum = 0;
            if (int.TryParse(randNumTxt.Text, out userNum))
            {
                    randNum = new RandNum(userNum);
                    NumOutPut.Items.Add("You entered " + randNum.UserNum);//I have this to show the user what number they did enter
                    NumOutPut.Items.Add(RandNum.MakeDocument(userNum));
                    //And this is calling the file creator from the library that will generate those numbers for them
                    // and let them know that it has been saved
            }
            else
                MessageBox.Show("Please enter a valid input into the box");//If a int is not input
        }
        
        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();// Closes the program
        }

        private void readNumBtn_Click(object sender, EventArgs e)
        {
            string[] lines = System.IO.File.ReadAllLines(@"C:\Users\Duke1\Downloads\RandomNumberFileWriter(EarlyTest)\RandomNumberFileWriter\WinUI\bin\Debug\Random_Numbers.txt");
            ReadNumOut.Items.Add("Hear are the randomly generated numbers");
            foreach (string line in lines)
            {
                ReadNumOut.Items.Add(line);
            }
        }
    }
}
