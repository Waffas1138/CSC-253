﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonalInformation
{
    public class PersonaInformation
    {
        public PersonaInformation(string firstName, string lastName, int age, string animal)
        {
            // Setting the variables so they will be empty and the user can input whatever they would like
            FirstName = firstName;
            LastName = lastName;
            Age = age;
            Animal = animal;
        }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
        public string Animal { get; set;  }
    }
}
