﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PersonalInformation
{
    public static class Writer
    {
        public static string WriterToFile(string firstName, string lastName, int age, string animal)
        {
            //Call's the variables that we're created and then will create a CSV with the input
            StreamWriter output;
            try
            {
                //Try catch created so the it will display either a saved message or an exception if it did not save properly
                output = File.CreateText("Personal Information.csv");
                //Create's the writeline in the CSV with the coma seperated values so it is lined up correctly in it
                output.WriteLine($"{firstName}, {lastName}, {age}, {animal}");
                output.Close();
                return "Saved";
            }
            catch (Exception ex)
            {
                string exceptionMessage = ex.Message;
                return exceptionMessage;
            }
        }
    }
}
