﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PersonalInformation
{
    public static class Writer
    {
        public static string WriterToFile(string firstName, string lastName, int age, string animal)
        {
            StreamWriter output;
            try
            {
                output = File.CreateText("Personal Information.csv");
                output.WriteLine($"{firstName}, {lastName}, {age} {animal}");
                output.Close();
                return "Saved";
            }
            catch (Exception ex)
            {
                string exceptionMessage = ex.Message;
                return exceptionMessage;
            }
        }
    }
}
