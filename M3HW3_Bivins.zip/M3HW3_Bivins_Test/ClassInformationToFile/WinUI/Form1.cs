﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PersonalInformation;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        PersonaInformation personInformation;
        private void inputButton_Click(object sender, EventArgs e)
        {
            string firstName = firstNameTxt.Text, lastName = LastNameTxt.Text, animal = AnimalTxt.Text;
            int age = 0;
            if (!string.IsNullOrWhiteSpace(firstName) && !string.IsNullOrWhiteSpace(lastName) && int.TryParse(AgeTxt.Text, out age) && !string.IsNullOrWhiteSpace(animal))
            {
                personInformation = new PersonaInformation(firstName, lastName, age, animal);
                EnterFileBox.Items.Add("Hello there" + personInformation.FirstName + personInformation.LastName);
                EnterFileBox.Items.Add("you are " + personInformation.Age + " years old and like " + personInformation.Animal);
                EnterFileBox.Items.Add(Writer.WriterToFile(firstName, lastName, age, animal));
            }
            else
                MessageBox.Show("Please enter a valid input into the box");
        }

        private void outputButton_Click(object sender, EventArgs e)
        {

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
