﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fNameLabel = new System.Windows.Forms.Label();
            this.lNameLabel = new System.Windows.Forms.Label();
            this.ageLabel = new System.Windows.Forms.Label();
            this.favAnimalLabel = new System.Windows.Forms.Label();
            this.firstNameTxt = new System.Windows.Forms.TextBox();
            this.LastNameTxt = new System.Windows.Forms.TextBox();
            this.AnimalTxt = new System.Windows.Forms.TextBox();
            this.AgeTxt = new System.Windows.Forms.TextBox();
            this.inputButton = new System.Windows.Forms.Button();
            this.outputButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.ReadFileBox = new System.Windows.Forms.ListBox();
            this.EnterFileBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // fNameLabel
            // 
            this.fNameLabel.AutoSize = true;
            this.fNameLabel.Location = new System.Drawing.Point(85, 39);
            this.fNameLabel.Name = "fNameLabel";
            this.fNameLabel.Size = new System.Drawing.Size(60, 13);
            this.fNameLabel.TabIndex = 0;
            this.fNameLabel.Text = "First Name:";
            // 
            // lNameLabel
            // 
            this.lNameLabel.AutoSize = true;
            this.lNameLabel.Location = new System.Drawing.Point(84, 91);
            this.lNameLabel.Name = "lNameLabel";
            this.lNameLabel.Size = new System.Drawing.Size(61, 13);
            this.lNameLabel.TabIndex = 1;
            this.lNameLabel.Text = "Last Name:";
            // 
            // ageLabel
            // 
            this.ageLabel.AutoSize = true;
            this.ageLabel.Location = new System.Drawing.Point(416, 32);
            this.ageLabel.Name = "ageLabel";
            this.ageLabel.Size = new System.Drawing.Size(29, 13);
            this.ageLabel.TabIndex = 2;
            this.ageLabel.Text = "Age:";
            // 
            // favAnimalLabel
            // 
            this.favAnimalLabel.AutoSize = true;
            this.favAnimalLabel.Location = new System.Drawing.Point(416, 95);
            this.favAnimalLabel.Name = "favAnimalLabel";
            this.favAnimalLabel.Size = new System.Drawing.Size(79, 13);
            this.favAnimalLabel.TabIndex = 3;
            this.favAnimalLabel.Text = "Favorite Animal";
            // 
            // firstNameTxt
            // 
            this.firstNameTxt.Location = new System.Drawing.Point(218, 32);
            this.firstNameTxt.Name = "firstNameTxt";
            this.firstNameTxt.Size = new System.Drawing.Size(124, 20);
            this.firstNameTxt.TabIndex = 4;
            // 
            // LastNameTxt
            // 
            this.LastNameTxt.Location = new System.Drawing.Point(218, 88);
            this.LastNameTxt.Name = "LastNameTxt";
            this.LastNameTxt.Size = new System.Drawing.Size(124, 20);
            this.LastNameTxt.TabIndex = 5;
            // 
            // AnimalTxt
            // 
            this.AnimalTxt.Location = new System.Drawing.Point(501, 92);
            this.AnimalTxt.Name = "AnimalTxt";
            this.AnimalTxt.Size = new System.Drawing.Size(124, 20);
            this.AnimalTxt.TabIndex = 6;
            // 
            // AgeTxt
            // 
            this.AgeTxt.Location = new System.Drawing.Point(479, 32);
            this.AgeTxt.Name = "AgeTxt";
            this.AgeTxt.Size = new System.Drawing.Size(124, 20);
            this.AgeTxt.TabIndex = 7;
            // 
            // inputButton
            // 
            this.inputButton.Location = new System.Drawing.Point(45, 158);
            this.inputButton.Name = "inputButton";
            this.inputButton.Size = new System.Drawing.Size(124, 60);
            this.inputButton.TabIndex = 8;
            this.inputButton.Text = "Input data into a file";
            this.inputButton.UseVisualStyleBackColor = true;
            this.inputButton.Click += new System.EventHandler(this.inputButton_Click);
            // 
            // outputButton
            // 
            this.outputButton.Location = new System.Drawing.Point(352, 158);
            this.outputButton.Name = "outputButton";
            this.outputButton.Size = new System.Drawing.Size(116, 60);
            this.outputButton.TabIndex = 9;
            this.outputButton.Text = "Read data from your file";
            this.outputButton.UseVisualStyleBackColor = true;
            this.outputButton.Click += new System.EventHandler(this.outputButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(558, 158);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(128, 60);
            this.exitButton.TabIndex = 10;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // ReadFileBox
            // 
            this.ReadFileBox.FormattingEnabled = true;
            this.ReadFileBox.Location = new System.Drawing.Point(352, 257);
            this.ReadFileBox.Name = "ReadFileBox";
            this.ReadFileBox.Size = new System.Drawing.Size(222, 160);
            this.ReadFileBox.TabIndex = 11;
            // 
            // EnterFileBox
            // 
            this.EnterFileBox.FormattingEnabled = true;
            this.EnterFileBox.Location = new System.Drawing.Point(45, 257);
            this.EnterFileBox.Name = "EnterFileBox";
            this.EnterFileBox.Size = new System.Drawing.Size(222, 160);
            this.EnterFileBox.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.EnterFileBox);
            this.Controls.Add(this.ReadFileBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.outputButton);
            this.Controls.Add(this.inputButton);
            this.Controls.Add(this.AgeTxt);
            this.Controls.Add(this.AnimalTxt);
            this.Controls.Add(this.LastNameTxt);
            this.Controls.Add(this.firstNameTxt);
            this.Controls.Add(this.favAnimalLabel);
            this.Controls.Add(this.ageLabel);
            this.Controls.Add(this.lNameLabel);
            this.Controls.Add(this.fNameLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label fNameLabel;
        private System.Windows.Forms.Label lNameLabel;
        private System.Windows.Forms.Label ageLabel;
        private System.Windows.Forms.Label favAnimalLabel;
        private System.Windows.Forms.TextBox firstNameTxt;
        private System.Windows.Forms.TextBox LastNameTxt;
        private System.Windows.Forms.TextBox AnimalTxt;
        private System.Windows.Forms.TextBox AgeTxt;
        private System.Windows.Forms.Button inputButton;
        private System.Windows.Forms.Button outputButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ListBox ReadFileBox;
        private System.Windows.Forms.ListBox EnterFileBox;
    }
}

