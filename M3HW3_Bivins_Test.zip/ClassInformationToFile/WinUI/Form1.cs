﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PersonalInformation;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        PersonaInformation personInformation;
        private void inputButton_Click(object sender, EventArgs e)
        {
            string firstName = "", lastName = "", animal = "";
            int age = 0;
            if (int.TryParse(AgeTxt.Text, out age))
            {
                personInformation = new PersonaInformation(firstName, lastName, age, animal);
                EnterFileBox.Items.Add(PersonaInformation.MakeDocument);
            }
            else
                MessageBox.Show("Please enter a valid input into the box");
        }

        private void outputButton_Click(object sender, EventArgs e)
        {

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
