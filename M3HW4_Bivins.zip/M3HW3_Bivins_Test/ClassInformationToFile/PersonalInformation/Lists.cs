﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonalInformation
{
    public static class Lists
    {
        public static List<PersonaInformation> info = new List<PersonaInformation>();
        //Creates a static list that will be available anywhere and so that the StreamReader can use it to display the file
    }
}
