﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PersonalInformation
{
    public static class Reader
    {
        public static string ReadToFile()
        {
            StreamReader inputFile;
            try
            {
                //Finds the file and opens it named Personal Information
                inputFile = File.OpenText("Personal Information.csv");
                while (!inputFile.EndOfStream)
                {
                    
                    string[] Tokens = inputFile.ReadLine().Split(',');
                    //Reads the file in the folder as well as uses Tokens to split up and properly read the CSV file
                    Lists.info.Add(new PersonaInformation(Tokens[0], Tokens[1], int.Parse(Tokens[2]), Tokens[3]));
                }
                   
                inputFile.Close();
                return "Loaded";
            }
            catch (Exception ex)
            {
                //Exception Message for error
                string exceptionMessage = ex.Message;
                return exceptionMessage;
            }
        }
    }
}
