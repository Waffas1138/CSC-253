﻿/**
* 9/22/2021
* CSC 253
* Travis Bivins
* a program that lets the user input their first name and last name, age and thier favorite animal and then putting it into a file and then going to
*  let the user see the file when it is read in the second listbox
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PersonalInformation;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        PersonaInformation personInformation;
        private void inputButton_Click(object sender, EventArgs e)
        {
            string firstName = firstNameTxt.Text, lastName = LastNameTxt.Text, animal = AnimalTxt.Text;
            int age = 0;
            //Catch in place so it will spit out an error if any of the textbox fields are left empty
            if (!string.IsNullOrWhiteSpace(firstName) && !string.IsNullOrWhiteSpace(lastName) && int.TryParse(AgeTxt.Text, out age) && !string.IsNullOrWhiteSpace(animal))
            {
                personInformation = new PersonaInformation(firstName, lastName, age, animal);
                // calls the variables from the library as well as will display the saved message in the list box for the created file
                EnterFileBox.Items.Add(Writer.WriterToFile(firstName, lastName, age, animal));
                
            }
            else
                MessageBox.Show("Please enter a valid input into the box");
        }

        private void outputButton_Click(object sender, EventArgs e)
        {
           Reader.ReadToFile();
            foreach(PersonaInformation person in Lists.info)
            {
                //This loop will display all the information from the List that was created and then display it into the listbox for the user to see
                ReadFileBox.Items.Add("Hello there " + person.FirstName + person.LastName);
                ReadFileBox.Items.Add("You are of " + person.Age + " years old and your favorite animal is " + person.Animal);
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //closes
            this.Close();
        }
    }
}
