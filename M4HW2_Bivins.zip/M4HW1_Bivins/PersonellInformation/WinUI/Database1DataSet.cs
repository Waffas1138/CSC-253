﻿namespace WinUI
{


    partial class Database1DataSet
    {
    }
}

namespace WinUI.Database1DataSetTableAdapters {
    
    
    public partial class PersonellTableAdapter {
    }
}
