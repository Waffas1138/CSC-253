﻿/**
* 10/2/2021
* CSC 253
* Travis Bivins
* Uses the Personell data Table and will now sort from Low-High or High-Low pay scale wise from the user
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void exit_Click(object sender, EventArgs e)
        {
            //Closes the program
            this.Close();
        }

        private void dispalyButton_Click(object sender, EventArgs e)
        {
            //Shows the table at its regualr self
            this.personellTableAdapter.Fill(this.database1DataSet.Personell);
        }

        private void PayRateAsc_Click(object sender, EventArgs e)
        {
            //Will rearrange the table from Lowest to highest Paid employee
            this.personellTableAdapter.FillByLow(this.database1DataSet.Personell);
        }

        private void PayHighToLowBtn_Click(object sender, EventArgs e)
        {
            //Will rearrange the table from Highest to Lowest Paid Employee
            this.personellTableAdapter.FillByPayHigh(this.database1DataSet.Personell);
        }
    }
}
