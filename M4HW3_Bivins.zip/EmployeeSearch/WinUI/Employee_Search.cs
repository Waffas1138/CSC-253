﻿/**
* 10/4/21
* CSC 253
* Travis Bivins
* An expanded part from the previous Personell Database but now the user can go to another form to searh for the employees from the table
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PersonellDBLibrary;
namespace WinUI
{
    public partial class Employee_Search : Form
    {
        public Employee_Search()
        {
            InitializeComponent();
        }
        private void Employee_Search_Load(object sender, EventArgs e)
        {
      
        }

        private void searchBttn_Click(object sender, EventArgs e)
        {
            //This will search the table and show the results based on what the user has put in if any fields of the table match
            this.personellTableAdapter.FillByName(this.database1DataSet.Personell, employeeNameTxt.Text);
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            Personell back = new Personell();
            //This is used to go back to the first form if the user would like to see everything and the pay sorting
            back.Show();
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            //Closes the program
            this.Close();
        }
    }
}
