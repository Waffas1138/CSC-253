﻿/**
* 10/4/21
* CSC 253
* Travis Bivins
* An expanded part from the previous Personell Database but now the user can go to another form to searh for the employees from the table
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PersonellDBLibrary;
namespace WinUI
{
    public partial class Personell : Form
    {
        public Personell()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           

        }

        private void dispalyButton_Click(object sender, EventArgs e)
        {
            //Shows the table at its regualr self
            this.personellTableAdapter.Fill(this.database1DataSet.Personell);
        }

        private void PayRateAsc_Click(object sender, EventArgs e)
        {
            //Will rearrange the table from Lowest to highest Paid employee
            this.personellTableAdapter.FillByPayLow(this.database1DataSet.Personell);
        }

        private void PayHighToLowBtn_Click(object sender, EventArgs e)
        {
            //Will rearrange the table from Highest to Lowest Paid Employee
            this.personellTableAdapter.FillByPayHigh(this.database1DataSet.Personell);
        }

        private void exit_Click(object sender, EventArgs e)
        {
            //Closes the program
            this.Close();
        }

        private void searchBtn_Click(object sender, EventArgs e)
        {
            Employee_Search search = new Employee_Search();
            //This will take the user to the Employee Search form so they can try to find the Employee they need
            search.Show();
        }
    }
}
