﻿/**
* 10/4/21
* CSC 253
* Travis Bivins
* An expanded part from the previous Personell Database but now the user can go to another form to searh for the employees from the table
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonellDBLibrary
{
    public class Personell_Table
    {
        //This class library is just being used to hold the database and the table
    }
}
