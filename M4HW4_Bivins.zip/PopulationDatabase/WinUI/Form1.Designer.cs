﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.cityAtoZbtn = new System.Windows.Forms.Button();
            this.popAscBtn = new System.Windows.Forms.Button();
            this.popDescBtn = new System.Windows.Forms.Button();
            this.exitBtn = new System.Windows.Forms.Button();
            this.popSumBtn = new System.Windows.Forms.Button();
            this.cityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.populationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.populationDBDataSet = new WinUI.PopulationDBDataSet();
            this.cityTableAdapter = new WinUI.PopulationDBDataSetTableAdapters.CityTableAdapter();
            this.avgBtn = new System.Windows.Forms.Button();
            this.highestPopBtn = new System.Windows.Forms.Button();
            this.lowestPopBtn = new System.Windows.Forms.Button();
            this.displayUpdateBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cityBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.populationDBDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cityDataGridViewTextBoxColumn,
            this.populationDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.cityBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 29);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(546, 208);
            this.dataGridView1.TabIndex = 0;
            // 
            // cityAtoZbtn
            // 
            this.cityAtoZbtn.Location = new System.Drawing.Point(29, 255);
            this.cityAtoZbtn.Name = "cityAtoZbtn";
            this.cityAtoZbtn.Size = new System.Drawing.Size(106, 58);
            this.cityAtoZbtn.TabIndex = 1;
            this.cityAtoZbtn.Text = "Display Cities from A-z";
            this.cityAtoZbtn.UseVisualStyleBackColor = true;
            this.cityAtoZbtn.Click += new System.EventHandler(this.cityAtoZbtn_Click);
            // 
            // popAscBtn
            // 
            this.popAscBtn.Location = new System.Drawing.Point(169, 255);
            this.popAscBtn.Name = "popAscBtn";
            this.popAscBtn.Size = new System.Drawing.Size(106, 58);
            this.popAscBtn.TabIndex = 2;
            this.popAscBtn.Text = "Display Population from Low-High";
            this.popAscBtn.UseVisualStyleBackColor = true;
            this.popAscBtn.Click += new System.EventHandler(this.popAscBtn_Click);
            // 
            // popDescBtn
            // 
            this.popDescBtn.Location = new System.Drawing.Point(315, 255);
            this.popDescBtn.Name = "popDescBtn";
            this.popDescBtn.Size = new System.Drawing.Size(106, 58);
            this.popDescBtn.TabIndex = 3;
            this.popDescBtn.Text = "Display Population from High-Low";
            this.popDescBtn.UseVisualStyleBackColor = true;
            this.popDescBtn.Click += new System.EventHandler(this.popDescBtn_Click);
            // 
            // exitBtn
            // 
            this.exitBtn.Location = new System.Drawing.Point(606, 29);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(106, 58);
            this.exitBtn.TabIndex = 4;
            this.exitBtn.Text = "Exit";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // popSumBtn
            // 
            this.popSumBtn.Location = new System.Drawing.Point(457, 255);
            this.popSumBtn.Name = "popSumBtn";
            this.popSumBtn.Size = new System.Drawing.Size(101, 57);
            this.popSumBtn.TabIndex = 5;
            this.popSumBtn.Text = "Display the Sum of all the population";
            this.popSumBtn.UseVisualStyleBackColor = true;
            this.popSumBtn.Click += new System.EventHandler(this.popSumBtn_Click);
            // 
            // cityDataGridViewTextBoxColumn
            // 
            this.cityDataGridViewTextBoxColumn.DataPropertyName = "City";
            this.cityDataGridViewTextBoxColumn.HeaderText = "City";
            this.cityDataGridViewTextBoxColumn.Name = "cityDataGridViewTextBoxColumn";
            // 
            // populationDataGridViewTextBoxColumn
            // 
            this.populationDataGridViewTextBoxColumn.DataPropertyName = "Population";
            this.populationDataGridViewTextBoxColumn.HeaderText = "Population";
            this.populationDataGridViewTextBoxColumn.Name = "populationDataGridViewTextBoxColumn";
            // 
            // cityBindingSource
            // 
            this.cityBindingSource.DataMember = "City";
            this.cityBindingSource.DataSource = this.populationDBDataSet;
            // 
            // populationDBDataSet
            // 
            this.populationDBDataSet.DataSetName = "PopulationDBDataSet";
            this.populationDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cityTableAdapter
            // 
            this.cityTableAdapter.ClearBeforeFill = true;
            // 
            // avgBtn
            // 
            this.avgBtn.Location = new System.Drawing.Point(320, 331);
            this.avgBtn.Name = "avgBtn";
            this.avgBtn.Size = new System.Drawing.Size(101, 69);
            this.avgBtn.TabIndex = 6;
            this.avgBtn.Text = "Display the average population";
            this.avgBtn.UseVisualStyleBackColor = true;
            this.avgBtn.Click += new System.EventHandler(this.avgBtn_Click);
            // 
            // highestPopBtn
            // 
            this.highestPopBtn.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.highestPopBtn.Location = new System.Drawing.Point(29, 340);
            this.highestPopBtn.Name = "highestPopBtn";
            this.highestPopBtn.Size = new System.Drawing.Size(106, 60);
            this.highestPopBtn.TabIndex = 7;
            this.highestPopBtn.Text = "Display the highest Population";
            this.highestPopBtn.UseVisualStyleBackColor = true;
            this.highestPopBtn.Click += new System.EventHandler(this.highestPopBtn_Click);
            // 
            // lowestPopBtn
            // 
            this.lowestPopBtn.Location = new System.Drawing.Point(169, 340);
            this.lowestPopBtn.Name = "lowestPopBtn";
            this.lowestPopBtn.Size = new System.Drawing.Size(106, 60);
            this.lowestPopBtn.TabIndex = 8;
            this.lowestPopBtn.Text = "Display the lowest Population";
            this.lowestPopBtn.UseVisualStyleBackColor = true;
            this.lowestPopBtn.Click += new System.EventHandler(this.lowestPopBtn_Click);
            // 
            // displayUpdateBtn
            // 
            this.displayUpdateBtn.Location = new System.Drawing.Point(606, 127);
            this.displayUpdateBtn.Name = "displayUpdateBtn";
            this.displayUpdateBtn.Size = new System.Drawing.Size(106, 58);
            this.displayUpdateBtn.TabIndex = 9;
            this.displayUpdateBtn.Text = "Click here to update, delete or add new data";
            this.displayUpdateBtn.UseVisualStyleBackColor = true;
            this.displayUpdateBtn.Click += new System.EventHandler(this.displayUpdateBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.displayUpdateBtn);
            this.Controls.Add(this.lowestPopBtn);
            this.Controls.Add(this.highestPopBtn);
            this.Controls.Add(this.avgBtn);
            this.Controls.Add(this.popSumBtn);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.popDescBtn);
            this.Controls.Add(this.popAscBtn);
            this.Controls.Add(this.cityAtoZbtn);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Population Database";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cityBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.populationDBDataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private PopulationDBDataSet populationDBDataSet;
        private System.Windows.Forms.BindingSource cityBindingSource;
        private PopulationDBDataSetTableAdapters.CityTableAdapter cityTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn cityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn populationDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button cityAtoZbtn;
        private System.Windows.Forms.Button popAscBtn;
        private System.Windows.Forms.Button popDescBtn;
        private System.Windows.Forms.Button exitBtn;
        private System.Windows.Forms.Button popSumBtn;
        private System.Windows.Forms.Button avgBtn;
        private System.Windows.Forms.Button highestPopBtn;
        private System.Windows.Forms.Button lowestPopBtn;
        private System.Windows.Forms.Button displayUpdateBtn;
    }
}

