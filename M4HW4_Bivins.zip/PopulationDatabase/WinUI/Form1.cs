﻿/**
* 10-10-2021
* CSC 253
* Travis Bivins
*A program with a database based on population from various cities that the user can organize how they'd like and enter in their own data
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PopulationDB;
namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void cityAtoZbtn_Click(object sender, EventArgs e)
        {
            //This is used to Filter the Cities from A-Z in order
            this.cityTableAdapter.FillByCityAtoZ(this.populationDBDataSet.City);
        }

        private void popAscBtn_Click(object sender, EventArgs e)
        {
            //This is going to filter the cities population from Lowest to Highest
            this.cityTableAdapter.FillByCityPopAsc(this.populationDBDataSet.City);
        }

        private void popDescBtn_Click(object sender, EventArgs e)
        {
            //This is going to filter the cities population from highest to lowest
            this.cityTableAdapter.FillByCityPopDesc(this.populationDBDataSet.City);
  
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            //Closes the form/program
            this.Close();
        }

        private void popSumBtn_Click(object sender, EventArgs e)
        {
            //This will grab the data from every entry into the population tab and add it all together inorder to ge the total sum
            int populationSum;
            populationSum = (int)this.cityTableAdapter.popSumQuery();
            MessageBox.Show("The sum of all the populations from the cities is: " + populationSum.ToString());
        }

        private void avgBtn_Click(object sender, EventArgs e)
        {
            //This will do its calculations from the population tab to get the average population count
            int populationAvg;
            populationAvg = (int)this.cityTableAdapter.popAvgQuery();
            MessageBox.Show("The average of all the populations from the cities is: " + populationAvg.ToString());

        }

        private void highestPopBtn_Click(object sender, EventArgs e)
        {
            //Will retrieve the highest population count that is in the table
            int populationHigh;
            populationHigh = (int)this.cityTableAdapter.HighPopQuery();
            MessageBox.Show("The highest Population data we could find in this table is: " + populationHigh.ToString());
        }

        private void lowestPopBtn_Click(object sender, EventArgs e)
        {
            //Will retrieve the lowest population count that is in the table
            int populationLow;
            populationLow = (int)this.cityTableAdapter.LowPopQuery();
            MessageBox.Show("The Lowest Population data we could find in this table is: " + populationLow.ToString());
        }

        private void displayUpdateBtn_Click(object sender, EventArgs e)
        {
            //Calls the second form we created and will pop it up so the user can enter new information into the table
            PopulationUserEnter update = new PopulationUserEnter();

            update.ShowDialog();

            this.cityTableAdapter.Fill(this.populationDBDataSet.City);
        }
    }
}
