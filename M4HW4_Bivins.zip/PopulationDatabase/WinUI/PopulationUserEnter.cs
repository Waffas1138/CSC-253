﻿/**
* 10-10-2021
* CSC 253
* Travis Bivins
*A program with a database based on population from various cities that the user can organize how they'd like and enter in their own data
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class PopulationUserEnter : Form
    {
        public PopulationUserEnter()
        {
            InitializeComponent();
        }

        private void cityBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cityBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.populationDBDataSet);

        }

        private void PopulationUserEnter_Load(object sender, EventArgs e)
        {
            //Loads the Table so you can change it up as needed
            this.cityTableAdapter.Fill(this.populationDBDataSet.City);

        }

        private void cityTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void cityLabel_Click(object sender, EventArgs e)
        {

        }

        private void populationLabel_Click(object sender, EventArgs e)
        {

        }

        private void populationTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            //Closes the form
            this.Close();
        }
    }
}
