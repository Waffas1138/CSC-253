﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeProductionLibrary
{
    // Child class
    public class ProductionWorker: Employee
    {
        public int ShiftNum { get; set; }
        public decimal HourlyRate { get; set; }
    }
}
