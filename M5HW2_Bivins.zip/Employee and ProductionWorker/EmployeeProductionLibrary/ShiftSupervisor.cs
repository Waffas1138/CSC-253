﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeProductionLibrary
{
    public class ShiftSupervisor: Employee
    {
        public decimal annualSalary { get; set; }
        public decimal annualProductionBonus { get; set; }
    }
}
