﻿
namespace WinUI
{
    partial class Shift_Supervisor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitBtn = new System.Windows.Forms.Button();
            this.outputLable = new System.Windows.Forms.Label();
            this.displayBtn = new System.Windows.Forms.Button();
            this.annualBonusTxt = new System.Windows.Forms.TextBox();
            this.payrateLabel = new System.Windows.Forms.Label();
            this.numberTxt = new System.Windows.Forms.TextBox();
            this.nameTxt = new System.Windows.Forms.TextBox();
            this.shiftSupervisornumberLabel = new System.Windows.Forms.Label();
            this.nameLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.annualSalary = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // exitBtn
            // 
            this.exitBtn.Location = new System.Drawing.Point(98, 442);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(187, 50);
            this.exitBtn.TabIndex = 24;
            this.exitBtn.Text = "Exit";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // outputLable
            // 
            this.outputLable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLable.Cursor = System.Windows.Forms.Cursors.Default;
            this.outputLable.Location = new System.Drawing.Point(42, 305);
            this.outputLable.Name = "outputLable";
            this.outputLable.Size = new System.Drawing.Size(293, 120);
            this.outputLable.TabIndex = 23;
            // 
            // displayBtn
            // 
            this.displayBtn.Location = new System.Drawing.Point(239, 254);
            this.displayBtn.Name = "displayBtn";
            this.displayBtn.Size = new System.Drawing.Size(95, 28);
            this.displayBtn.TabIndex = 21;
            this.displayBtn.Text = "Display";
            this.displayBtn.UseVisualStyleBackColor = true;
            this.displayBtn.Click += new System.EventHandler(this.displayBtn_Click);
            // 
            // annualBonusTxt
            // 
            this.annualBonusTxt.Location = new System.Drawing.Point(157, 222);
            this.annualBonusTxt.Name = "annualBonusTxt";
            this.annualBonusTxt.Size = new System.Drawing.Size(192, 20);
            this.annualBonusTxt.TabIndex = 20;
            // 
            // payrateLabel
            // 
            this.payrateLabel.AutoSize = true;
            this.payrateLabel.Location = new System.Drawing.Point(12, 225);
            this.payrateLabel.Name = "payrateLabel";
            this.payrateLabel.Size = new System.Drawing.Size(139, 13);
            this.payrateLabel.TabIndex = 19;
            this.payrateLabel.Text = "Annual Prodcution Bonus: $";
            // 
            // numberTxt
            // 
            this.numberTxt.Location = new System.Drawing.Point(142, 92);
            this.numberTxt.Name = "numberTxt";
            this.numberTxt.Size = new System.Drawing.Size(192, 20);
            this.numberTxt.TabIndex = 18;
            // 
            // nameTxt
            // 
            this.nameTxt.Location = new System.Drawing.Point(142, 26);
            this.nameTxt.Name = "nameTxt";
            this.nameTxt.Size = new System.Drawing.Size(192, 20);
            this.nameTxt.TabIndex = 17;
            // 
            // shiftSupervisornumberLabel
            // 
            this.shiftSupervisornumberLabel.AutoSize = true;
            this.shiftSupervisornumberLabel.Location = new System.Drawing.Point(16, 95);
            this.shiftSupervisornumberLabel.Name = "shiftSupervisornumberLabel";
            this.shiftSupervisornumberLabel.Size = new System.Drawing.Size(96, 13);
            this.shiftSupervisornumberLabel.TabIndex = 16;
            this.shiftSupervisornumberLabel.Text = "Employee Number:";
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(16, 29);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(115, 13);
            this.nameLabel.TabIndex = 15;
            this.nameLabel.Text = "Shift Supervisor Name:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 154);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 13);
            this.label1.TabIndex = 28;
            this.label1.Text = "Annual Salary: $";
            // 
            // annualSalary
            // 
            this.annualSalary.Location = new System.Drawing.Point(143, 151);
            this.annualSalary.Name = "annualSalary";
            this.annualSalary.Size = new System.Drawing.Size(192, 20);
            this.annualSalary.TabIndex = 29;
            // 
            // Shift_Supervisor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(373, 516);
            this.Controls.Add(this.annualSalary);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.outputLable);
            this.Controls.Add(this.displayBtn);
            this.Controls.Add(this.annualBonusTxt);
            this.Controls.Add(this.payrateLabel);
            this.Controls.Add(this.numberTxt);
            this.Controls.Add(this.nameTxt);
            this.Controls.Add(this.shiftSupervisornumberLabel);
            this.Controls.Add(this.nameLabel);
            this.Name = "Shift_Supervisor";
            this.Text = "Shift_Supervisor";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button exitBtn;
        private System.Windows.Forms.Label outputLable;
        private System.Windows.Forms.Button displayBtn;
        private System.Windows.Forms.TextBox annualBonusTxt;
        private System.Windows.Forms.Label payrateLabel;
        private System.Windows.Forms.TextBox numberTxt;
        private System.Windows.Forms.TextBox nameTxt;
        private System.Windows.Forms.Label shiftSupervisornumberLabel;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox annualSalary;
    }
}