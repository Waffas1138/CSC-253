﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeProductionLibrary;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Shift_Supervisor : Form
    {
        //Shift Supervisor object
        ShiftSupervisor Supervisor = new ShiftSupervisor();
        public Shift_Supervisor()
        {
            InitializeComponent();
        }

        private void displayBtn_Click(object sender, EventArgs e)
        {
            try
            {
                Supervisor.Name = nameTxt.Text;
                Supervisor.Number = int.Parse(numberTxt.Text);
                Supervisor.annualSalary = decimal.Parse(annualSalary.Text);
                Supervisor.annualProductionBonus = decimal.Parse(annualBonusTxt.Text);
                outputLable.Text = "Shift Supervisor Name: " + Supervisor.Name + "\n" +
                                "Shift Supervisor Number: " + Supervisor.Number + "\n" +
                                "Annual Salary: " + Supervisor.annualSalary.ToString("c") + "\n" +
                                "Annual Production Bonus: " + Supervisor.annualProductionBonus.ToString("c");
            
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
