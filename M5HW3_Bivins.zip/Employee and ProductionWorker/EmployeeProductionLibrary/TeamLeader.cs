﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeProductionLibrary
{
    public class TeamLeader : Employee
    {
        public decimal monthlyBonus { get; set; }
        public int trainingHours { get; set; }
        public decimal hoursAttended { get; set; }
    }
}

