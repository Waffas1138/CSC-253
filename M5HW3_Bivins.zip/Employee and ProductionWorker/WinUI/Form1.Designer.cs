﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameLabel = new System.Windows.Forms.Label();
            this.numberLabel = new System.Windows.Forms.Label();
            this.nameTxt = new System.Windows.Forms.TextBox();
            this.numberTxt = new System.Windows.Forms.TextBox();
            this.payrateLabel = new System.Windows.Forms.Label();
            this.payrateTxt = new System.Windows.Forms.TextBox();
            this.displayBtn = new System.Windows.Forms.Button();
            this.shiftNumLabel = new System.Windows.Forms.Label();
            this.outputLable = new System.Windows.Forms.Label();
            this.exitBtn = new System.Windows.Forms.Button();
            this.nightRaioBtn = new System.Windows.Forms.RadioButton();
            this.dayRadioBtn = new System.Windows.Forms.RadioButton();
            this.shiftSupervisorBtn = new System.Windows.Forms.Button();
            this.teamLeaderBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(17, 34);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(87, 13);
            this.nameLabel.TabIndex = 0;
            this.nameLabel.Text = "Employee Name:";
            // 
            // numberLabel
            // 
            this.numberLabel.AutoSize = true;
            this.numberLabel.Location = new System.Drawing.Point(17, 100);
            this.numberLabel.Name = "numberLabel";
            this.numberLabel.Size = new System.Drawing.Size(96, 13);
            this.numberLabel.TabIndex = 1;
            this.numberLabel.Text = "Employee Number:";
            // 
            // nameTxt
            // 
            this.nameTxt.Location = new System.Drawing.Point(143, 31);
            this.nameTxt.Name = "nameTxt";
            this.nameTxt.Size = new System.Drawing.Size(192, 20);
            this.nameTxt.TabIndex = 2;
            // 
            // numberTxt
            // 
            this.numberTxt.Location = new System.Drawing.Point(143, 97);
            this.numberTxt.Name = "numberTxt";
            this.numberTxt.Size = new System.Drawing.Size(192, 20);
            this.numberTxt.TabIndex = 3;
            // 
            // payrateLabel
            // 
            this.payrateLabel.AutoSize = true;
            this.payrateLabel.Location = new System.Drawing.Point(17, 230);
            this.payrateLabel.Name = "payrateLabel";
            this.payrateLabel.Size = new System.Drawing.Size(96, 13);
            this.payrateLabel.TabIndex = 4;
            this.payrateLabel.Text = "Hourly Pay Rate: $";
            // 
            // payrateTxt
            // 
            this.payrateTxt.Location = new System.Drawing.Point(144, 227);
            this.payrateTxt.Name = "payrateTxt";
            this.payrateTxt.Size = new System.Drawing.Size(192, 20);
            this.payrateTxt.TabIndex = 5;
            // 
            // displayBtn
            // 
            this.displayBtn.Location = new System.Drawing.Point(240, 259);
            this.displayBtn.Name = "displayBtn";
            this.displayBtn.Size = new System.Drawing.Size(95, 28);
            this.displayBtn.TabIndex = 6;
            this.displayBtn.Text = "Display";
            this.displayBtn.UseVisualStyleBackColor = true;
            this.displayBtn.Click += new System.EventHandler(this.displayBtn_Click);
            // 
            // shiftNumLabel
            // 
            this.shiftNumLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.shiftNumLabel.Location = new System.Drawing.Point(13, 141);
            this.shiftNumLabel.Name = "shiftNumLabel";
            this.shiftNumLabel.Size = new System.Drawing.Size(323, 70);
            this.shiftNumLabel.TabIndex = 9;
            this.shiftNumLabel.Text = "Shift Number:";
            // 
            // outputLable
            // 
            this.outputLable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLable.Cursor = System.Windows.Forms.Cursors.Default;
            this.outputLable.Location = new System.Drawing.Point(31, 310);
            this.outputLable.Name = "outputLable";
            this.outputLable.Size = new System.Drawing.Size(305, 120);
            this.outputLable.TabIndex = 10;
            // 
            // exitBtn
            // 
            this.exitBtn.Location = new System.Drawing.Point(113, 496);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(128, 41);
            this.exitBtn.TabIndex = 11;
            this.exitBtn.Text = "Exit";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // nightRaioBtn
            // 
            this.nightRaioBtn.AutoSize = true;
            this.nightRaioBtn.Location = new System.Drawing.Point(259, 168);
            this.nightRaioBtn.Name = "nightRaioBtn";
            this.nightRaioBtn.Size = new System.Drawing.Size(65, 17);
            this.nightRaioBtn.TabIndex = 12;
            this.nightRaioBtn.TabStop = true;
            this.nightRaioBtn.Text = "Night (2)";
            this.nightRaioBtn.UseVisualStyleBackColor = true;
            this.nightRaioBtn.CheckedChanged += new System.EventHandler(this.nightRaioBtn_CheckedChanged);
            // 
            // dayRadioBtn
            // 
            this.dayRadioBtn.AutoSize = true;
            this.dayRadioBtn.Location = new System.Drawing.Point(182, 168);
            this.dayRadioBtn.Name = "dayRadioBtn";
            this.dayRadioBtn.Size = new System.Drawing.Size(59, 17);
            this.dayRadioBtn.TabIndex = 13;
            this.dayRadioBtn.TabStop = true;
            this.dayRadioBtn.Text = "Day (1)";
            this.dayRadioBtn.UseVisualStyleBackColor = true;
            this.dayRadioBtn.CheckedChanged += new System.EventHandler(this.dayRadioByn_CheckedChanged);
            // 
            // shiftSupervisorBtn
            // 
            this.shiftSupervisorBtn.Location = new System.Drawing.Point(31, 449);
            this.shiftSupervisorBtn.Name = "shiftSupervisorBtn";
            this.shiftSupervisorBtn.Size = new System.Drawing.Size(144, 41);
            this.shiftSupervisorBtn.TabIndex = 14;
            this.shiftSupervisorBtn.Text = "Check Shift Supervisor";
            this.shiftSupervisorBtn.UseVisualStyleBackColor = true;
            this.shiftSupervisorBtn.Click += new System.EventHandler(this.shiftSupervisorBtn_Click);
            // 
            // teamLeaderBtn
            // 
            this.teamLeaderBtn.Location = new System.Drawing.Point(192, 449);
            this.teamLeaderBtn.Name = "teamLeaderBtn";
            this.teamLeaderBtn.Size = new System.Drawing.Size(144, 41);
            this.teamLeaderBtn.TabIndex = 15;
            this.teamLeaderBtn.Text = "Check Team Leader";
            this.teamLeaderBtn.UseVisualStyleBackColor = true;
            this.teamLeaderBtn.Click += new System.EventHandler(this.teamLeaderBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(369, 549);
            this.Controls.Add(this.teamLeaderBtn);
            this.Controls.Add(this.shiftSupervisorBtn);
            this.Controls.Add(this.dayRadioBtn);
            this.Controls.Add(this.nightRaioBtn);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.outputLable);
            this.Controls.Add(this.shiftNumLabel);
            this.Controls.Add(this.displayBtn);
            this.Controls.Add(this.payrateTxt);
            this.Controls.Add(this.payrateLabel);
            this.Controls.Add(this.numberTxt);
            this.Controls.Add(this.nameTxt);
            this.Controls.Add(this.numberLabel);
            this.Controls.Add(this.nameLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label numberLabel;
        private System.Windows.Forms.TextBox nameTxt;
        private System.Windows.Forms.TextBox numberTxt;
        private System.Windows.Forms.Label payrateLabel;
        private System.Windows.Forms.TextBox payrateTxt;
        private System.Windows.Forms.Button displayBtn;
        private System.Windows.Forms.Label shiftNumLabel;
        private System.Windows.Forms.Label outputLable;
        private System.Windows.Forms.Button exitBtn;
        private System.Windows.Forms.RadioButton nightRaioBtn;
        private System.Windows.Forms.RadioButton dayRadioBtn;
        private System.Windows.Forms.Button shiftSupervisorBtn;
        private System.Windows.Forms.Button teamLeaderBtn;
    }
}

