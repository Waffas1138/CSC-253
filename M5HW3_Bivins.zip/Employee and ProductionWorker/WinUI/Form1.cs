﻿/**
* 10/27/2021
* CSC 253
* Travis Bivins
* This is an extension on the previous two homework entries but now it is adding the Team Leader role for the user to fill out a
* and will be adding their Monthly Bonus, and the amount of training hours that are required and the amount they have taken so far
* by using parent and child classes to pass the information to one another to send back to the user on the form
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeProductionLibrary;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        // ProductionWorker object
        ProductionWorker pdWorker = new ProductionWorker();
        public Form1()
        {
            InitializeComponent();
        }

        private void displayBtn_Click(object sender, EventArgs e)
        {
            try
            {
                //Sets up all the textboxs to the corresponding fields from the parent and child classes 
                pdWorker.Name = nameTxt.Text;
                pdWorker.Number = int.Parse(numberTxt.Text);
                pdWorker.HourlyRate = decimal.Parse(payrateTxt.Text);
                outputLable.Text = "Employee Name: " + pdWorker.Name + "\n" +
                                "Employee Number: " + pdWorker.Number + "\n" +
                                "Shift Number: " + pdWorker.ShiftNum + "\n" +
                                "Hourly pay rate: " + pdWorker.HourlyRate.ToString("c");
            }
            catch(Exception ex)
            {
                //Catch message to pop up incase the user inputs an incorrect entry into any of the fields
                MessageBox.Show(ex.Message);
            }
        }

        

        private void exitBtn_Click(object sender, EventArgs e)
        {
            //closes the program
            this.Close();
        }

        private void dayRadioByn_CheckedChanged(object sender, EventArgs e)
        {
            if (dayRadioBtn.Checked)
            {
                //if statement for the day shift button so it will auto change workers shift number to 1 for day
                pdWorker.ShiftNum = 1;
            }
        }

        private void nightRaioBtn_CheckedChanged(object sender, EventArgs e)
        {
            if (nightRaioBtn.Checked)
            {
                //if statement for the night shift button so it will auto change workers shift number to 2 for night 
                pdWorker.ShiftNum = 2;
            }
        }

        private void shiftSupervisorBtn_Click(object sender, EventArgs e)
        {
            Shift_Supervisor shift = new Shift_Supervisor();
            shift.Show();
        }

        private void teamLeaderBtn_Click(object sender, EventArgs e)
        {
            // Opens the Team Leader form to enter their information 
            Team_Leader team = new Team_Leader();
            team.Show();
        }
    }
}
