﻿
namespace WinUI
{
    partial class Team_Leader
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.monthlyBonusTxt = new System.Windows.Forms.TextBox();
            this.monthBonus = new System.Windows.Forms.Label();
            this.exitBtn = new System.Windows.Forms.Button();
            this.outputLable = new System.Windows.Forms.Label();
            this.displayBtn = new System.Windows.Forms.Button();
            this.trainingHoursLabel = new System.Windows.Forms.Label();
            this.numberTxt = new System.Windows.Forms.TextBox();
            this.nameTxt = new System.Windows.Forms.TextBox();
            this.shiftSupervisornumberLabel = new System.Windows.Forms.Label();
            this.nameLabel = new System.Windows.Forms.Label();
            this.trainingHoursTxt = new System.Windows.Forms.TextBox();
            this.hoursAttended = new System.Windows.Forms.Label();
            this.hoursAttendedTxt = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // monthlyBonusTxt
            // 
            this.monthlyBonusTxt.Location = new System.Drawing.Point(189, 146);
            this.monthlyBonusTxt.Name = "monthlyBonusTxt";
            this.monthlyBonusTxt.Size = new System.Drawing.Size(192, 20);
            this.monthlyBonusTxt.TabIndex = 40;
            // 
            // monthBonus
            // 
            this.monthBonus.AutoSize = true;
            this.monthBonus.Location = new System.Drawing.Point(36, 149);
            this.monthBonus.Name = "monthBonus";
            this.monthBonus.Size = new System.Drawing.Size(83, 13);
            this.monthBonus.TabIndex = 39;
            this.monthBonus.Text = "Monthly Bonus: ";
            // 
            // exitBtn
            // 
            this.exitBtn.Location = new System.Drawing.Point(108, 535);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(187, 50);
            this.exitBtn.TabIndex = 38;
            this.exitBtn.Text = "Exit";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // outputLable
            // 
            this.outputLable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputLable.Cursor = System.Windows.Forms.Cursors.Default;
            this.outputLable.Location = new System.Drawing.Point(52, 357);
            this.outputLable.Name = "outputLable";
            this.outputLable.Size = new System.Drawing.Size(293, 161);
            this.outputLable.TabIndex = 37;
            // 
            // displayBtn
            // 
            this.displayBtn.Location = new System.Drawing.Point(108, 301);
            this.displayBtn.Name = "displayBtn";
            this.displayBtn.Size = new System.Drawing.Size(187, 43);
            this.displayBtn.TabIndex = 36;
            this.displayBtn.Text = "Display";
            this.displayBtn.UseVisualStyleBackColor = true;
            this.displayBtn.Click += new System.EventHandler(this.displayBtn_Click);
            // 
            // trainingHoursLabel
            // 
            this.trainingHoursLabel.AutoSize = true;
            this.trainingHoursLabel.Location = new System.Drawing.Point(9, 220);
            this.trainingHoursLabel.Name = "trainingHoursLabel";
            this.trainingHoursLabel.Size = new System.Drawing.Size(161, 13);
            this.trainingHoursLabel.TabIndex = 34;
            this.trainingHoursLabel.Text = "Minimum training hours required: ";
            // 
            // numberTxt
            // 
            this.numberTxt.Location = new System.Drawing.Point(189, 87);
            this.numberTxt.Name = "numberTxt";
            this.numberTxt.Size = new System.Drawing.Size(192, 20);
            this.numberTxt.TabIndex = 33;
            // 
            // nameTxt
            // 
            this.nameTxt.Location = new System.Drawing.Point(189, 21);
            this.nameTxt.Name = "nameTxt";
            this.nameTxt.Size = new System.Drawing.Size(192, 20);
            this.nameTxt.TabIndex = 32;
            // 
            // shiftSupervisornumberLabel
            // 
            this.shiftSupervisornumberLabel.AutoSize = true;
            this.shiftSupervisornumberLabel.Location = new System.Drawing.Point(36, 94);
            this.shiftSupervisornumberLabel.Name = "shiftSupervisornumberLabel";
            this.shiftSupervisornumberLabel.Size = new System.Drawing.Size(96, 13);
            this.shiftSupervisornumberLabel.TabIndex = 31;
            this.shiftSupervisornumberLabel.Text = "Employee Number:";
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(36, 28);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(104, 13);
            this.nameLabel.TabIndex = 30;
            this.nameLabel.Text = "Team Leader Name:";
            // 
            // trainingHoursTxt
            // 
            this.trainingHoursTxt.Location = new System.Drawing.Point(189, 217);
            this.trainingHoursTxt.Name = "trainingHoursTxt";
            this.trainingHoursTxt.Size = new System.Drawing.Size(192, 20);
            this.trainingHoursTxt.TabIndex = 41;
            // 
            // hoursAttended
            // 
            this.hoursAttended.AutoSize = true;
            this.hoursAttended.Location = new System.Drawing.Point(9, 278);
            this.hoursAttended.Name = "hoursAttended";
            this.hoursAttended.Size = new System.Drawing.Size(174, 13);
            this.hoursAttended.TabIndex = 42;
            this.hoursAttended.Text = "How many training hours attended: ";
            // 
            // hoursAttendedTxt
            // 
            this.hoursAttendedTxt.Location = new System.Drawing.Point(189, 275);
            this.hoursAttendedTxt.Name = "hoursAttendedTxt";
            this.hoursAttendedTxt.Size = new System.Drawing.Size(192, 20);
            this.hoursAttendedTxt.TabIndex = 43;
            // 
            // Team_Leader
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(392, 616);
            this.Controls.Add(this.hoursAttendedTxt);
            this.Controls.Add(this.hoursAttended);
            this.Controls.Add(this.trainingHoursTxt);
            this.Controls.Add(this.monthlyBonusTxt);
            this.Controls.Add(this.monthBonus);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.outputLable);
            this.Controls.Add(this.displayBtn);
            this.Controls.Add(this.trainingHoursLabel);
            this.Controls.Add(this.numberTxt);
            this.Controls.Add(this.nameTxt);
            this.Controls.Add(this.shiftSupervisornumberLabel);
            this.Controls.Add(this.nameLabel);
            this.Name = "Team_Leader";
            this.Text = "Team_Leader";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox monthlyBonusTxt;
        private System.Windows.Forms.Label monthBonus;
        private System.Windows.Forms.Button exitBtn;
        private System.Windows.Forms.Label outputLable;
        private System.Windows.Forms.Button displayBtn;
        private System.Windows.Forms.Label trainingHoursLabel;
        private System.Windows.Forms.TextBox numberTxt;
        private System.Windows.Forms.TextBox nameTxt;
        private System.Windows.Forms.Label shiftSupervisornumberLabel;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.TextBox trainingHoursTxt;
        private System.Windows.Forms.Label hoursAttended;
        private System.Windows.Forms.TextBox hoursAttendedTxt;
    }
}