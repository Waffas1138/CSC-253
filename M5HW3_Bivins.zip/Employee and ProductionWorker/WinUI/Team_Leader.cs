﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeProductionLibrary;

namespace WinUI
{
    public partial class Team_Leader : Form
    {
        //Calling the child TeamLeader class to use inside this form
        TeamLeader team = new TeamLeader();
        public Team_Leader()
        {
            InitializeComponent();
        }

        private void displayBtn_Click(object sender, EventArgs e)
        {
            try
            {
                //Try catch set up to spit the error message incase the user inputs an incorrect value into any of the fields
                // While also spitting back out the Team Leaders Name, Employee number, monthly bonus and the training hours they are required as well as the amount they have taken
                team.Name = nameTxt.Text;
                team.Number = int.Parse(numberTxt.Text);
                team.monthlyBonus = decimal.Parse(monthlyBonusTxt.Text);
                team.trainingHours = int.Parse(trainingHoursTxt.Text);
                team.hoursAttended = decimal.Parse(hoursAttendedTxt.Text);
                outputLable.Text = "Team Leader Name: " + team.Name + "\n" +
                                    "Team Leader Number: " + team.Number + "\n" +
                                    "Monthly Bonus : " + team.monthlyBonus.ToString("c") + "\n" +
                                    "You have attended " + team.hoursAttended + " hours out of your required " + team.trainingHours + " required hours";

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            // Closes the TeamLeader form and takes you back to the regular Employee form
            this.Close();
        }
    }
}
