﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringExtensionLibrary
{
    public class StringExtension
    {
        public StringExtension(string userInput)
        {
            UserInput = userInput;
        }
        public string UserInput { get; set; }
        public int CountWords(string count)
        {
            //Split is to be used so it will split the words by spaces inorder to be counted
            string[] totalWords = count.Split(' ');
            // also returns the number of the length of the words that have been entered and skips the spaces so they do not get counted
            return totalWords.Length;
        }
        public string Reverse(string userInput)
        {
            //This will spit the string back in reverse to the user by first creating the array then reverseing the letter
            char[] charArray = userInput.ToCharArray();
            Array.Reverse(charArray);
            return new string(charArray);
        }
        public string Date(string userInput)
        {
            // This will output and show the date to the user if they enter Jan, 1 2000 for example
            string dateInput = userInput;
            var parsedDate = DateTime.Parse(dateInput);
            return Convert.ToString(parsedDate);
        }
        public string PhoneNum(string userInput)
        {
           //Takes the users string and formats it into a phone number for them to see
            string phone = String.Format("{0:(###) ###-####}", userInput);
            return phone;
        }
        public string ArrayString(string userInput)
        {
            //This goes and takes the string but turns it into an array instead
            string str = userInput;
            char[] ch = str.ToCharArray();
            foreach (char c in ch)
            {
                return Convert.ToString(c);
            }
            return "";
        }
    }
  
}

