﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.stringLabel = new System.Windows.Forms.Label();
            this.stringText = new System.Windows.Forms.TextBox();
            this.convertToArrayBtn = new System.Windows.Forms.Button();
            this.DateFormatBtn = new System.Windows.Forms.Button();
            this.phoneNumBtn = new System.Windows.Forms.Button();
            this.numWordBtn = new System.Windows.Forms.Button();
            this.backwardsBtn = new System.Windows.Forms.Button();
            this.exitBtn = new System.Windows.Forms.Button();
            this.numInput = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // stringLabel
            // 
            this.stringLabel.AutoSize = true;
            this.stringLabel.Location = new System.Drawing.Point(41, 47);
            this.stringLabel.Name = "stringLabel";
            this.stringLabel.Size = new System.Drawing.Size(136, 13);
            this.stringLabel.TabIndex = 0;
            this.stringLabel.Text = "Please enter your sentence";
            // 
            // stringText
            // 
            this.stringText.Location = new System.Drawing.Point(183, 47);
            this.stringText.Name = "stringText";
            this.stringText.Size = new System.Drawing.Size(294, 20);
            this.stringText.TabIndex = 1;
            // 
            // convertToArrayBtn
            // 
            this.convertToArrayBtn.Location = new System.Drawing.Point(195, 85);
            this.convertToArrayBtn.Name = "convertToArrayBtn";
            this.convertToArrayBtn.Size = new System.Drawing.Size(133, 48);
            this.convertToArrayBtn.TabIndex = 2;
            this.convertToArrayBtn.Text = "Convert String to Array";
            this.convertToArrayBtn.UseVisualStyleBackColor = true;
            this.convertToArrayBtn.Click += new System.EventHandler(this.convertToArrayBtn_Click);
            // 
            // DateFormatBtn
            // 
            this.DateFormatBtn.Location = new System.Drawing.Point(195, 241);
            this.DateFormatBtn.Name = "DateFormatBtn";
            this.DateFormatBtn.Size = new System.Drawing.Size(133, 48);
            this.DateFormatBtn.TabIndex = 3;
            this.DateFormatBtn.Text = "Formant into Date";
            this.DateFormatBtn.UseVisualStyleBackColor = true;
            this.DateFormatBtn.Click += new System.EventHandler(this.DateFormatBtn_Click);
            // 
            // phoneNumBtn
            // 
            this.phoneNumBtn.Location = new System.Drawing.Point(344, 241);
            this.phoneNumBtn.Name = "phoneNumBtn";
            this.phoneNumBtn.Size = new System.Drawing.Size(133, 48);
            this.phoneNumBtn.TabIndex = 4;
            this.phoneNumBtn.Text = "Format into telephone number";
            this.phoneNumBtn.UseVisualStyleBackColor = true;
            this.phoneNumBtn.Click += new System.EventHandler(this.phoneNumBtn_Click);
            // 
            // numWordBtn
            // 
            this.numWordBtn.Location = new System.Drawing.Point(44, 85);
            this.numWordBtn.Name = "numWordBtn";
            this.numWordBtn.Size = new System.Drawing.Size(133, 48);
            this.numWordBtn.TabIndex = 5;
            this.numWordBtn.Text = "Count the Number of words in the sentence";
            this.numWordBtn.UseVisualStyleBackColor = true;
            this.numWordBtn.Click += new System.EventHandler(this.numWordBtn_Click);
            // 
            // backwardsBtn
            // 
            this.backwardsBtn.Location = new System.Drawing.Point(344, 85);
            this.backwardsBtn.Name = "backwardsBtn";
            this.backwardsBtn.Size = new System.Drawing.Size(133, 48);
            this.backwardsBtn.TabIndex = 6;
            this.backwardsBtn.Text = "Return String Backwards";
            this.backwardsBtn.UseVisualStyleBackColor = true;
            this.backwardsBtn.Click += new System.EventHandler(this.backwardsBtn_Click);
            // 
            // exitBtn
            // 
            this.exitBtn.Location = new System.Drawing.Point(195, 343);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(133, 48);
            this.exitBtn.TabIndex = 7;
            this.exitBtn.Text = "Exit";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // numInput
            // 
            this.numInput.Location = new System.Drawing.Point(229, 183);
            this.numInput.Name = "numInput";
            this.numInput.Size = new System.Drawing.Size(294, 20);
            this.numInput.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 183);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(194, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Please enter the Date or Phone number";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numInput);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.backwardsBtn);
            this.Controls.Add(this.numWordBtn);
            this.Controls.Add(this.phoneNumBtn);
            this.Controls.Add(this.DateFormatBtn);
            this.Controls.Add(this.convertToArrayBtn);
            this.Controls.Add(this.stringText);
            this.Controls.Add(this.stringLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label stringLabel;
        private System.Windows.Forms.TextBox stringText;
        private System.Windows.Forms.Button convertToArrayBtn;
        private System.Windows.Forms.Button DateFormatBtn;
        private System.Windows.Forms.Button phoneNumBtn;
        private System.Windows.Forms.Button numWordBtn;
        private System.Windows.Forms.Button backwardsBtn;
        private System.Windows.Forms.Button exitBtn;
        private System.Windows.Forms.TextBox numInput;
        private System.Windows.Forms.Label label1;
    }
}

