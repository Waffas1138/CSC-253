﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringExtensionLibrary
{
    public class StringExtension
    {
        public StringExtension(string userInput)
        {
            UserInput = userInput;
        }
        public string UserInput { get; set; }
        public int CountWords(string count)
        {
            //Split is to be used so it will split the words by spaces inorder to be counted
            string[] totalWords = count.Split(' ');
            // also returns the number of the length of the words that have been entered and skips the spaces so they do not get counted
            return totalWords.Length;
        }
        public string Reverse(string userInput)
        {
            char[] charArray = userInput.ToCharArray();
            Array.Reverse(charArray);
            return new string(charArray);
        }
    }
  
}

