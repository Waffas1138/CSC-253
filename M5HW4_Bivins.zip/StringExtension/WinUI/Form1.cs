﻿/**
* 10/27/2021
* CSC 253
* Travis Bivins
* This porogram is using multiple string extension methods to demonstrate what you can do with them such as converting string to Char
*  or return it backwards for example
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using StringExtensionLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }
        StringExtension stringExtension;
        private void convertToArrayBtn_Click(object sender, EventArgs e)
        {
            
        }

        private void DateFormatBtn_Click(object sender, EventArgs e)
        {

        }

        private void phoneNumBtn_Click(object sender, EventArgs e)
        {

        }

        private void backwardsBtn_Click(object sender, EventArgs e)
        {
            string userInput = stringText.Text.Trim();
            if (!string.IsNullOrWhiteSpace(userInput))
            {
                stringExtension = new StringExtension(userInput);

                MessageBox.Show("Here is your sentence but in reverse " + stringExtension.Reverse(userInput));
            }
            else
            {
                MessageBox.Show("Please enter a valid input into the text box.");
            }
        }

        private void numWordBtn_Click(object sender, EventArgs e)
        {
            string userInput = stringText.Text.Trim();
            if (!string.IsNullOrWhiteSpace(userInput))
            {
                stringExtension = new StringExtension(userInput);

                MessageBox.Show("There was a total of " + stringExtension.CountWords(userInput) + " words in your sentence");
            }
            else
            {
                MessageBox.Show("Please enter a valid input into the text box.");
            }
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       
    }
}
