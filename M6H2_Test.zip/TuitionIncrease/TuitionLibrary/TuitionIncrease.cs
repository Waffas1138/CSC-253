﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TuitionLibrary
{
    public class TuitionIncrease
    {
        public TuitionIncrease()
        {
            
        }

        public string TuitionRate()
        {
                string display;
                double tuition = 6000;
                double increase = 0;
                double rate = 0.02;
                for(int year =1; year <=5; year++)
                {
                if (year > 1)
                    {
                    increase = tuition * rate;
                    }
                    tuition = increase + tuition;
                    display = "year " + year.ToString() + ": " + " Amount " + "$" + tuition;
                    
                    
                }
            return "";
        }
    }
   
}
