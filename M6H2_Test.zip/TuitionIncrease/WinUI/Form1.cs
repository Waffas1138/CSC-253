﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TuitionLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        TuitionIncrease tuitionIncrease;
        public Form1()
        {
            InitializeComponent();
        }

        private void displayBtn_Click(object sender, EventArgs e)
        {
            //tuitionIncrease = new TuitionIncrease();
            //tuitionListBox.Items.Add("Your tuition for the following semester will be " + tuitionIncrease.TuitionRate());
            string display;
            double tuition = 6000;
            double increase = 0;
            double rate = 0.02;
            for (int year = 1; year <= 5; year++)
            {
                if (year > 1)
                {
                    increase = tuition * rate;
                }
                tuition = increase + tuition;
                display = "year " + year.ToString() + ": " + " Amount " + "$" + tuition;
                tuitionListBox.Items.Add(display);

            }
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
