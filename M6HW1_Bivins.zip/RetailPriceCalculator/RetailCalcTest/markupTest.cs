﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RetailPriceLibrary;
using Xunit;

namespace RetailCalcTest
{
   
    public class markupTest
    {
        [Fact]
        public void CalculateRetail_Markup_Add()
        {

            // Arange
            // Initializes the objects and will set the values in order to test without running the whole program
            double wholesale = 5;
            double markup = 50;
            double expected = 7.5;
            var retail = new RetailCalc(wholesale, markup);
            // Act
            // This will invoke the method to test and make sure the calculations will work with the correct value returned
            retail.CalculateRetail(wholesale, markup);
            // Assert
            // And this verifies that the expected result is correct and everything is green and ready to go
            Assert.Equal(expected, expected);
        }
    }
}

