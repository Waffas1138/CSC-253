﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailPriceLibrary
{
    public class RetailCalc
    {
        public RetailCalc(double markup, double wholesale)
        {
            Markup = markup;
            WholeSale = wholesale;

        }
        public double Markup { get; set; }
        public double WholeSale { get; set; }
        public double CalculateRetail(double wholesale, double markup)
        {
            // This sets up the retail price calculation by dividing the marked up percentage of the tiem by 100 to get the percent for the item
            // and afterwards it will take the wholesale normal lsited price and times it by the markup then add it back to it to return to the user the new price
            double markupPercent = markup / 100;
            double retailPrice;

            retailPrice = wholesale + (wholesale * markupPercent);
            return retailPrice;
        }
    }
}
