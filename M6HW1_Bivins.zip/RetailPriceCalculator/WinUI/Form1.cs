﻿/**
* 11/8/2021
* CSC 253
* Travis Bivins
* An updated verson of our old Retail Price calculator that will now use unit testing for validation for the program without having to 
* run the program every time to test it and will now be able to be tested without starting the program
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RetailPriceLibrary;
namespace WinUI
{
    public partial class TotalForm : Form
    {
        RetailCalc retailCalc;
        public TotalForm()
        {
            InitializeComponent();
        }

        private void Calcbutton_Click(object sender, EventArgs e)
        {
            double wholesale;
            double markup;

            if (double.TryParse(RetailTextBox.Text, out wholesale) && double.TryParse(MarkIpTextBox.Text, out markup))
            {
                // Try parse set up so the user has to enter a number into the markup and wholesale price labels and can not enter anything else, 
                // if they do then it will spit out an arror message for them

                // Calls the retailCalc library and assigns it to the variables on the form and then will call the calculateRetail method
                // in order to get the correct price and display it back to the user
                retailCalc = new RetailCalc(wholesale, markup);
                double retailPrice;
                retailPrice = retailCalc.CalculateRetail(wholesale, markup);
                TotaltextBox.Text = retailPrice.ToString("C");
            }
            else
                MessageBox.Show("Please enter a valid number.");
        }
       

        private void Exitbutton_Click(object sender, EventArgs e)
        {
            // Closes the form/ends the program
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
