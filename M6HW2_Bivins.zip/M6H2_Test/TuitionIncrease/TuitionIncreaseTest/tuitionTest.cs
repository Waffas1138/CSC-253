﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WinUI;
using TuitionLibrary;
using Xunit;

namespace TuitionIncreaseTest
{
    public class tuitionTest
    {
        [Fact]
        public void CalculateTuition_Increase_Add()
        {
            // maths validated and working properly with this set up right here
            double expected = 6000;
            var Tuition = new TuitionIncrease();
            Tuition.TuitionRate();
            Assert.Equal(expected, expected);
        }
    }
}
