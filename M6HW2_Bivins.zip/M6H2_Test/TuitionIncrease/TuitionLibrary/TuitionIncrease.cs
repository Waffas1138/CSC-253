﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TuitionLibrary
{
    public class TuitionIncrease
    {
        public TuitionIncrease()
        {
        }

        public string TuitionRate()
        {
            // does the loop and math for calculations
                string display;
                double tuition = 6000;
                double increase = 0;
                double rate = 0.02;
                for(int year =1; year <=5; year++)
                {
                if (year > 1)
                    {
                    increase = tuition * rate;
                    }
                    tuition = increase + tuition;
                    display = "year " + year.ToString() + ": " + " Amount " + "$" + tuition;
                // couldnt get it to showcase in the form so it will show in console ui when clicked
                    Console.WriteLine(display);
                    
                }
            
            return "";
        }
    }
   
}
