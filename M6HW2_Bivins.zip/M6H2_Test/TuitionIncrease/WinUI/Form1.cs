﻿/**
* 11/14/2021
* CSC 253
* Travis Bivins
* Creating unit test for tuition increase program to check validation with math
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TuitionLibrary;

namespace WinUI
{
    public partial class Form1 : Form
    {
        TuitionIncrease tuitionIncrease;
        public Form1()
        {
            InitializeComponent();
        }

        private void displayBtn_Click(object sender, EventArgs e)
        {
            tuitionIncrease = new TuitionIncrease();
            //Calls the method to do the math and will show it in the console ui
            tuitionListBox.Items.Add(tuitionIncrease.TuitionRate());
           
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            //exits program
            this.Close();
        }
    }
}
