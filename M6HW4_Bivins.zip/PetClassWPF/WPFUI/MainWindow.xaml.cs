﻿/**
* 11/15/2021
* CSC 253
* Travis Bivins
* This program is an updated version of the pet class from before that now incorporates WPF aplication into it for the user to interact with
*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ButtonAddPetAge_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(petAge.Text) && !string.IsNullOrWhiteSpace(petType.Text) && !string.IsNullOrWhiteSpace(petName.Text))
            {
                // This one button will combine the Name, type and pet's age fields into one click event and then display it back to the user upon hitting it
                lstPets.Items.Add("Name: " + petName.Text + "\n Type: " + petType.Text + "\n Age:" + petAge.Text);
                // After hitting the button it will then proceed to clear the textboxes so the user can input another pet if they would like
                petName.Clear();
                petType.Clear();
                petAge.Clear();
            }
        }
    }
}
