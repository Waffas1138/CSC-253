﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace RandNumLibrary
{
    public class RandNum
    {
        public RandNum(int userNum)
        {
            UserNum = userNum;
            foreach (int num in userNum)
            {
                Random rand = new Random();
                int num = rand.Next(250);
            }
        }
        public int UserNum { get; set; }
        public static string MakeDocument(string input)
        {
            return input;
        }
    }
}
