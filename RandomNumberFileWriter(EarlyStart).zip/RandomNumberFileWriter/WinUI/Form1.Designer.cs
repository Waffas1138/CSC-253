﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.enterNumButton = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.randNumLabel = new System.Windows.Forms.Label();
            this.randNumTxt = new System.Windows.Forms.TextBox();
            this.NumOutPut = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // enterNumButton
            // 
            this.enterNumButton.Location = new System.Drawing.Point(59, 148);
            this.enterNumButton.Name = "enterNumButton";
            this.enterNumButton.Size = new System.Drawing.Size(194, 71);
            this.enterNumButton.TabIndex = 0;
            this.enterNumButton.Text = "Enter to get Random Number in your file";
            this.enterNumButton.UseVisualStyleBackColor = true;
            this.enterNumButton.Click += new System.EventHandler(this.enterNumButton_Click);
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(293, 148);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(194, 71);
            this.Exit.TabIndex = 1;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // randNumLabel
            // 
            this.randNumLabel.AutoSize = true;
            this.randNumLabel.Location = new System.Drawing.Point(61, 63);
            this.randNumLabel.Name = "randNumLabel";
            this.randNumLabel.Size = new System.Drawing.Size(192, 13);
            this.randNumLabel.TabIndex = 2;
            this.randNumLabel.Text = "Amount of Random Numbers you want:";
            // 
            // randNumTxt
            // 
            this.randNumTxt.Location = new System.Drawing.Point(259, 60);
            this.randNumTxt.Name = "randNumTxt";
            this.randNumTxt.Size = new System.Drawing.Size(228, 20);
            this.randNumTxt.TabIndex = 3;
            // 
            // NumOutPut
            // 
            this.NumOutPut.FormattingEnabled = true;
            this.NumOutPut.Location = new System.Drawing.Point(64, 272);
            this.NumOutPut.Name = "NumOutPut";
            this.NumOutPut.Size = new System.Drawing.Size(388, 121);
            this.NumOutPut.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.NumOutPut);
            this.Controls.Add(this.randNumTxt);
            this.Controls.Add(this.randNumLabel);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.enterNumButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button enterNumButton;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Label randNumLabel;
        private System.Windows.Forms.TextBox randNumTxt;
        private System.Windows.Forms.ListBox NumOutPut;
    }
}

