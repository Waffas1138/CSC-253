﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace RandNumLibrary
{
    public class RandNum
    {
        public RandNum(int userNum)
        {
            UserNum = userNum;
            //foreach (int num in userNum)
            //{
               //Random rand = new Random();
                //int num = rand.Next(250);
            //}
        }
        public int UserNum { get; set; }
        public static string MakeDocument(string userNum)
        {
            try
            {
                StreamWriter outputFile;
                outputFile = File.CreateText("Random Numbers.txt");
                outputFile.WriteLine(userNum);
                outputFile.Close();
                return "Save Complete";
            }
            catch(Exception ex)
            {
                string test = (ex.Message);
                return test;
            }
        }
    }
}
